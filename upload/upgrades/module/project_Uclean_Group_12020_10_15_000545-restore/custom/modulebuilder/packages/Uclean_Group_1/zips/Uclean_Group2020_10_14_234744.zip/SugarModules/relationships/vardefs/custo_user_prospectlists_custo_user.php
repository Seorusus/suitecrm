<?php
// created: 2020-10-14 23:47:43
$dictionary["custo_user"]["fields"]["custo_user_prospectlists"] = array (
  'name' => 'custo_user_prospectlists',
  'type' => 'link',
  'relationship' => 'custo_user_prospectlists',
  'source' => 'non-db',
  'module' => 'ProspectLists',
  'bean_name' => 'ProspectList',
  'vname' => 'LBL_CUSTO_USER_PROSPECTLISTS_FROM_PROSPECTLISTS_TITLE',
);
