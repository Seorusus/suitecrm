<?php
// created: 2020-10-14 23:47:44
$dictionary["Email"]["fields"]["custo_company_emails_1"] = array (
  'name' => 'custo_company_emails_1',
  'type' => 'link',
  'relationship' => 'custo_company_emails_1',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => 'custo_company',
  'vname' => 'LBL_CUSTO_COMPANY_EMAILS_1_FROM_CUSTO_COMPANY_TITLE',
);
