<?php
// created: 2020-10-14 23:47:42
$dictionary["SecurityGroup"]["fields"]["custo_user_securitygroups"] = array (
  'name' => 'custo_user_securitygroups',
  'type' => 'link',
  'relationship' => 'custo_user_securitygroups',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_USER_SECURITYGROUPS_FROM_CUSTO_USER_TITLE',
);
