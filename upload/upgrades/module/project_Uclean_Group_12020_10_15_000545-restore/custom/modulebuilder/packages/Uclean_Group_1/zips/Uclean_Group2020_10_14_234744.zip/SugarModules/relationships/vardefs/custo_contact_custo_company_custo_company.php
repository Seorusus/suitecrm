<?php
// created: 2020-10-14 23:47:42
$dictionary["custo_company"]["fields"]["custo_contact_custo_company"] = array (
  'name' => 'custo_contact_custo_company',
  'type' => 'link',
  'relationship' => 'custo_contact_custo_company',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'vname' => 'LBL_CUSTO_CONTACT_CUSTO_COMPANY_FROM_CUSTO_CONTACT_TITLE',
);
