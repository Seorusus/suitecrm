<?php
// created: 2020-10-14 23:47:43
$dictionary["custo_user"]["fields"]["custo_user_custo_company_1"] = array (
  'name' => 'custo_user_custo_company_1',
  'type' => 'link',
  'relationship' => 'custo_user_custo_company_1',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => 'custo_company',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_USER_CUSTO_COMPANY_1_FROM_CUSTO_COMPANY_TITLE',
);
