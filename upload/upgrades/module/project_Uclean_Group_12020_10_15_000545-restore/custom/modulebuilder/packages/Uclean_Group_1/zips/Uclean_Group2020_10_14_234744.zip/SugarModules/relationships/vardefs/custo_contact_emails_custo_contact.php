<?php
// created: 2020-10-14 23:47:42
$dictionary["custo_contact"]["fields"]["custo_contact_emails"] = array (
  'name' => 'custo_contact_emails',
  'type' => 'link',
  'relationship' => 'custo_contact_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_CUSTO_CONTACT_EMAILS_FROM_EMAILS_TITLE',
);
