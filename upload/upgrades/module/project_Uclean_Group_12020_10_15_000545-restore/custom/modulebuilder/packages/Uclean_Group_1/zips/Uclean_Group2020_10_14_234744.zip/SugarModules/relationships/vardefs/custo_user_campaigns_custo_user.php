<?php
// created: 2020-10-14 23:47:43
$dictionary["custo_user"]["fields"]["custo_user_campaigns"] = array (
  'name' => 'custo_user_campaigns',
  'type' => 'link',
  'relationship' => 'custo_user_campaigns',
  'source' => 'non-db',
  'module' => 'Campaigns',
  'bean_name' => 'Campaign',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_USER_CAMPAIGNS_FROM_CAMPAIGNS_TITLE',
);
