<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_CUSTO_USER_CUSTO_CONTACT_FROM_CUSTO_CONTACT_TITLE'] = 'Контакт Uclean_Group';
$mod_strings['LBL_CUSTO_USER_CUSTO_CONTACT_1_FROM_CUSTO_CONTACT_TITLE'] = 'Контакт Uclean_Group';
$mod_strings['LBL_CUSTO_USER_USERS_FROM_USERS_TITLE'] = 'Пользователи';
$mod_strings['LBL_CUSTO_USER_USERS_1_FROM_USERS_TITLE'] = 'Пользователи';
$mod_strings['LBL_CUSTO_USER_CUSTO_USER_FROM_CUSTO_USER_L_TITLE'] = 'Компания-партнер';
$mod_strings['LBL_CUSTO_USER_CUSTO_USER_FROM_CUSTO_USER_R_TITLE'] = 'Компания-партнер';
$mod_strings['LBL_CUSTO_USER_CUSTO_USER_1_FROM_CUSTO_USER_L_TITLE'] = 'Компания-партнер';
$mod_strings['LBL_CUSTO_USER_CUSTO_USER_1_FROM_CUSTO_USER_R_TITLE'] = 'Компания-партнер';
$mod_strings['LBL_CUSTO_USER_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE'] = 'Расширенные настройки безопасности';
$mod_strings['LBL_CUSTO_USER_SECURITYGROUPS_1_FROM_SECURITYGROUPS_TITLE'] = 'Расширенные настройки безопасности';
$mod_strings['LBL_CUSTO_USER_CUSTO_COMPANY_FROM_CUSTO_COMPANY_TITLE'] = 'Контрагент Uclean_Group';
$mod_strings['LBL_CUSTO_USER_CUSTO_COMPANY_1_FROM_CUSTO_COMPANY_TITLE'] = 'Контрагент Uclean_Group';
$mod_strings['LBL_CUSTO_USER_PROSPECTLISTS_FROM_PROSPECTLISTS_TITLE'] = 'Цели - списки';
$mod_strings['LBL_CUSTO_USER_CALLS_FROM_CALLS_TITLE'] = 'Звонки';
$mod_strings['LBL_CUSTO_USER_TASKS_FROM_TASKS_TITLE'] = 'Задачи';
$mod_strings['LBL_CUSTO_USER_MEETINGS_FROM_MEETINGS_TITLE'] = 'Встречи';
$mod_strings['LBL_CUSTO_USER_EMAILS_FROM_EMAILS_TITLE'] = 'E-mail';
$mod_strings['LBL_CUSTO_USER_EMAILS_1_FROM_EMAILS_TITLE'] = 'E-mail';
$mod_strings['LBL_CUSTO_USER_CALLS_1_FROM_CALLS_TITLE'] = 'Звонки';
$mod_strings['LBL_CUSTO_USER_TASKS_1_FROM_TASKS_TITLE'] = 'Задачи';
$mod_strings['LBL_CUSTO_USER_MEETINGS_1_FROM_MEETINGS_TITLE'] = 'Встречи';
$mod_strings['LBL_CUSTO_USER_INCOM_INCOMING_MARKETING_FROM_INCOM_INCOMING_MARKETING_TITLE'] = 'Входящий Маркетинг';
$mod_strings['LBL_CUSTO_USER_CAMPAIGNS_FROM_CAMPAIGNS_TITLE'] = 'Исходящий маркетинг';
