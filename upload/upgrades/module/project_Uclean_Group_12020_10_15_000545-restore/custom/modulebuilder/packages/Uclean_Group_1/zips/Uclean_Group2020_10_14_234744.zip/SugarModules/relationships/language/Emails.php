<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_CUSTO_CONTACT_EMAILS_FROM_CUSTO_CONTACT_TITLE'] = 'Контакт Uclean_Group';
$mod_strings['LBL_CUSTO_COMPANY_EMAILS_FROM_CUSTO_COMPANY_TITLE'] = 'Контрагент Uclean_Group';
$mod_strings['LBL_CUSTO_COMPANY_EMAILS_1_FROM_CUSTO_COMPANY_TITLE'] = 'Контрагент Uclean_Group';
