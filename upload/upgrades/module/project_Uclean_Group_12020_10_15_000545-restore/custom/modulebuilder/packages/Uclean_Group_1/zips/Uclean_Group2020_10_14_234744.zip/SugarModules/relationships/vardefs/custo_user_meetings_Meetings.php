<?php
// created: 2020-10-14 23:47:43
$dictionary["Meeting"]["fields"]["custo_user_meetings"] = array (
  'name' => 'custo_user_meetings',
  'type' => 'link',
  'relationship' => 'custo_user_meetings',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_USER_MEETINGS_FROM_CUSTO_USER_TITLE',
);
