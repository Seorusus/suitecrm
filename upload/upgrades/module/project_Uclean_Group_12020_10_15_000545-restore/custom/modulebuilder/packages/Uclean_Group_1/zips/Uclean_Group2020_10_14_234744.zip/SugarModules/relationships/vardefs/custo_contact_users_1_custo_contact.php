<?php
// created: 2020-10-14 23:47:42
$dictionary["custo_contact"]["fields"]["custo_contact_users_1"] = array (
  'name' => 'custo_contact_users_1',
  'type' => 'link',
  'relationship' => 'custo_contact_users_1',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_CUSTO_CONTACT_USERS_1_FROM_USERS_TITLE',
);
