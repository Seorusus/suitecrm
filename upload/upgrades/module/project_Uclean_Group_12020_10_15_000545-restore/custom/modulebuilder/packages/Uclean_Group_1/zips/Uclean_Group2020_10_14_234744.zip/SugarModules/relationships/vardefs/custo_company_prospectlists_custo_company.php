<?php
// created: 2020-10-14 23:47:44
$dictionary["custo_company"]["fields"]["custo_company_prospectlists"] = array (
  'name' => 'custo_company_prospectlists',
  'type' => 'link',
  'relationship' => 'custo_company_prospectlists',
  'source' => 'non-db',
  'module' => 'ProspectLists',
  'bean_name' => 'ProspectList',
  'vname' => 'LBL_CUSTO_COMPANY_PROSPECTLISTS_FROM_PROSPECTLISTS_TITLE',
);
