<?php
// created: 2020-10-14 23:47:44
$dictionary["custo_company"]["fields"]["custo_company_calls"] = array (
  'name' => 'custo_company_calls',
  'type' => 'link',
  'relationship' => 'custo_company_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_COMPANY_CALLS_FROM_CALLS_TITLE',
);
