<?php
// created: 2020-10-14 23:47:44
$dictionary["User"]["fields"]["custo_company_users"] = array (
  'name' => 'custo_company_users',
  'type' => 'link',
  'relationship' => 'custo_company_users',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => 'custo_company',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_COMPANY_USERS_FROM_CUSTO_COMPANY_TITLE',
);
