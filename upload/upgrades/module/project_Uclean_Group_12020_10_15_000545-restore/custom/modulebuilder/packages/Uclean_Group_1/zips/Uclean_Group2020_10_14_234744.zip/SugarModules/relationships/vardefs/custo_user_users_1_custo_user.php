<?php
// created: 2020-10-14 23:47:42
$dictionary["custo_user"]["fields"]["custo_user_users_1"] = array (
  'name' => 'custo_user_users_1',
  'type' => 'link',
  'relationship' => 'custo_user_users_1',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_USER_USERS_1_FROM_USERS_TITLE',
);
