<?php
// created: 2020-10-14 23:47:42
$dictionary["custo_user"]["fields"]["custo_user_securitygroups"] = array (
  'name' => 'custo_user_securitygroups',
  'type' => 'link',
  'relationship' => 'custo_user_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_CUSTO_USER_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
