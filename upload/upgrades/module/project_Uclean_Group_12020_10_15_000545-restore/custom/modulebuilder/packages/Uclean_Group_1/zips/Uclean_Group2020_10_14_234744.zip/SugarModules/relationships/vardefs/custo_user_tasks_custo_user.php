<?php
// created: 2020-10-14 23:47:43
$dictionary["custo_user"]["fields"]["custo_user_tasks"] = array (
  'name' => 'custo_user_tasks',
  'type' => 'link',
  'relationship' => 'custo_user_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'vname' => 'LBL_CUSTO_USER_TASKS_FROM_TASKS_TITLE',
);
