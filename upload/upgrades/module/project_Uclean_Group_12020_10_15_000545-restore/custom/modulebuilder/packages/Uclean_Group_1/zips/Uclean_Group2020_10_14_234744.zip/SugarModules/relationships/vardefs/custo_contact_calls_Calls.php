<?php
// created: 2020-10-14 23:47:42
$dictionary["Call"]["fields"]["custo_contact_calls"] = array (
  'name' => 'custo_contact_calls',
  'type' => 'link',
  'relationship' => 'custo_contact_calls',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'vname' => 'LBL_CUSTO_CONTACT_CALLS_FROM_CUSTO_CONTACT_TITLE',
);
