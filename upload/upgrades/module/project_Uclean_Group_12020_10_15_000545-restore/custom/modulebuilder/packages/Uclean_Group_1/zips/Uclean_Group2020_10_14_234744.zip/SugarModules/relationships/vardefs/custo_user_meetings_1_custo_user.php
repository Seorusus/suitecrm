<?php
// created: 2020-10-14 23:47:43
$dictionary["custo_user"]["fields"]["custo_user_meetings_1"] = array (
  'name' => 'custo_user_meetings_1',
  'type' => 'link',
  'relationship' => 'custo_user_meetings_1',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_USER_MEETINGS_1_FROM_MEETINGS_TITLE',
);
