<?php
// created: 2020-10-14 23:47:42
$dictionary["custo_contact"]["fields"]["custo_user_custo_contact_1"] = array (
  'name' => 'custo_user_custo_contact_1',
  'type' => 'link',
  'relationship' => 'custo_user_custo_contact_1',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_USER_CUSTO_CONTACT_1_FROM_CUSTO_USER_TITLE',
);
