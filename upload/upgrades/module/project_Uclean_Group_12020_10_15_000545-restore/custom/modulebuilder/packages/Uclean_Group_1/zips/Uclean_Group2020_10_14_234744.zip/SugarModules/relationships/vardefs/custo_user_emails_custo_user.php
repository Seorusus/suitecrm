<?php
// created: 2020-10-14 23:47:43
$dictionary["custo_user"]["fields"]["custo_user_emails"] = array (
  'name' => 'custo_user_emails',
  'type' => 'link',
  'relationship' => 'custo_user_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_CUSTO_USER_EMAILS_FROM_EMAILS_TITLE',
);
