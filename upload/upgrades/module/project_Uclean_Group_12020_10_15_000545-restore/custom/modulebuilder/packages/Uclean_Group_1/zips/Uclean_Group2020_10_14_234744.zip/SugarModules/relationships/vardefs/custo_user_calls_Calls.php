<?php
// created: 2020-10-14 23:47:43
$dictionary["Call"]["fields"]["custo_user_calls"] = array (
  'name' => 'custo_user_calls',
  'type' => 'link',
  'relationship' => 'custo_user_calls',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_USER_CALLS_FROM_CUSTO_USER_TITLE',
);
