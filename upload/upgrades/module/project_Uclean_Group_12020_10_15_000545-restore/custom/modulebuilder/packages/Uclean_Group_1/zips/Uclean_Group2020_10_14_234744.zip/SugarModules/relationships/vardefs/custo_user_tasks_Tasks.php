<?php
// created: 2020-10-14 23:47:43
$dictionary["Task"]["fields"]["custo_user_tasks"] = array (
  'name' => 'custo_user_tasks',
  'type' => 'link',
  'relationship' => 'custo_user_tasks',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_USER_TASKS_FROM_CUSTO_USER_TITLE',
);
