<?php
// created: 2020-10-14 23:47:43
$dictionary["custo_user"]["fields"]["custo_user_calls"] = array (
  'name' => 'custo_user_calls',
  'type' => 'link',
  'relationship' => 'custo_user_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_CUSTO_USER_CALLS_FROM_CALLS_TITLE',
);
