
var j = document.createElement('script');
j.src = "https://pilot.svicenter.com/include/ext/chromeExtHelper/jquery-1.10.2.min.js";
(document.head || document.documentElement).appendChild(j);

var g = document.createElement('script');
g.src = "https://pilot.svicenter.com/include/ext/chromeExtHelper/gmail.js";
(document.head || document.documentElement).appendChild(g);

var s = document.createElement('script');
s.src = "https://pilot.svicenter.com/include/ext/chromeMailExtension/main.js";
(document.head || document.documentElement).appendChild(s);
