<?php
header("Access-Control-Allow-Origin: *");

global $sugar_config;

if (!function_exists('print_array')) {
    function print_array($var, $exit = false, $in_file = false)
    {
        if($in_file) ob_start();

        if (!$in_file) echo '<pre>';
        print_r($var);
        if (!$in_file) echo '</pre>' . "\n";
        if ($in_file) $content = ob_get_contents();

        if ($in_file) {
            $file = fopen("cache/print_array.log", "a+");
            fwrite($file, "\n\n******************************\n");
            fwrite($file, date("Y-m-d H:i:s") . "\n");
            fwrite($file, $content);
            fclose($file);
            empty($file);

            ob_end_clean();
        }

        if ($exit) exit;
    }
}

if(isset($_REQUEST['action']) AND $_REQUEST['action'] == 'crmNotAuth') {
    // Определено, что нет авторизации в CRM
    $smarty = new Sugar_Smarty();

    $smarty->assign("SITE_URL", $sugar_config['site_url']);
    $smarty->assign("company_logo", SugarThemeRegistry::current()->getImageURL('company_logo.png'));
    $smarty->display("custom/include/chromeMailExtension/tpls/crmNotAuth.tpl");
    exit;
}


require_once('include/SugarFields/SugarFieldHandler.php');

global $db;
global $app_list_strings;
global $current_user;
global $current_language;
global $timedate;




// Определяем корректность токена
$tokenEnabled = false;
if(isset($_REQUEST['rnd']) AND isset($_REQUEST['token'])) {
    $tokenCurrent = md5($_REQUEST['rnd'] . '+' . date("Y-m-d"));
    if($tokenCurrent == $_REQUEST['token']) {
        // Токен прошел проверку
        $tokenEnabled = true;
    } else {
        // Токен проверку не прошел

        if(isset($_REQUEST['token']) AND $_REQUEST['token'] == '112233') {
            // бекдор для отладки
            $tokenEnabled = true;
        }
    }
}

if(!$tokenEnabled) {
    // Завершаем сценарий
    die(json_encode(array(
        'email_snippet' => '$tokenCurrent=' . $tokenCurrent .  var_export($_POST, true) . '<div class="xsr_contact_div" style="font-size: 13px; font-family:arial, sans-serif; font-weight: bold"><hr style="display: block; height: 1px; border: 0; border-top: 1px solid #ccc;  margin: 1em 0; padding: 0;"><ul><li>Invalid token!</li></ul></div>',
        'reply_snippet' => ''
    )));
}

// Текущий пользователь
$GLOBALS['current_user'] = new User();
$GLOBALS['current_user']->retrieve($_SESSION['authenticated_user_id']);
$current_user = $GLOBALS['current_user'];
$GLOBALS['current_language'] = 'ru_RU';


// Поля, которые заполняются при создании новой записи
$GLOBALS['newFields'] = [
    'Contacts' => [
        'first_name',
        'last_name',
        'title',
        'account_name',
        'email1',
        'email2',
        'phone_work',
        'phone_mobile',
        'phone_fax',
        'assigned_user_name' => [
            'function' => 'newObjectAssignedUser'
        ],
    ],
    'Tasks' => [
        'name',
        'date_start',
        'date_due',
        'priority',
        'description',
        'assigned_user_name' => [
            'function' => 'newObjectAssignedUser'
        ],
    ],
    'Notes' => [
        'name',
        'description',
        'assigned_user_name' => [
            'function' => 'newObjectAssignedUser'
        ],
    ],
    'Meetings' => [
        'name',
        'assigned_user_name' => [
            'function' => 'newObjectAssignedUser'
        ],
    ],
    'Calls' => [
        'name',
        'date_start',
        'duration_hours' => [
            'function' => 'getDurationHours'
        ],
        'duration_minutes',
        'direction',
        'status',
        'description',
        'assigned_user_name' => [
            'function' => 'newObjectAssignedUser'
        ],
    ],
    'Opportunities' => [
        'name',
        'amount',
        'date_closed',
        'description',
        'sales_stage',
        'opportunity_type',
        'lead_source',
        'assigned_user_name' => [
            'function' => 'newObjectAssignedUser'
        ],
    ],
    'Cases' => [
        'name',
        'priority',
        'status',
        'type',
        'description',
        'resolution',
        'assigned_user_name' => [
            'function' => 'newObjectAssignedUser'
        ],
    ],

];

// Поля, которые разрешено менять в расширении
$GLOBALS['editFields'] = [
    'Contacts' => [
        'title',
        'phone_work',
        'phone_mobile',
        'primary_address_street',
        'primary_address_city',
        'primary_address_state',
        'primary_address_postalcode',
        'primary_address_country',
    ],
];





if(isset($_REQUEST['action'])) {

    switch ($_REQUEST['action']) {

        case 'showInfoForEmail':
            // Получение данных о Контакте по переданному Email

            $smarty = new Sugar_Smarty();

            $contact_smarty = [];
            $account_smarty = [];
            $activities_smarty = [];
            $history_smarty = [];
            $opportunities_smarty = [];

            if(isset($_REQUEST['email'])) {
                // Если передали email
                // Получаем Контакт
                $sql = "
                        SELECT
                            `email_addr_bean_rel`.`bean_id`
                        FROM
                            `email_addr_bean_rel`
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` = '".strtoupper($_REQUEST['email'])."'
                        WHERE
                            `email_addr_bean_rel`.`deleted` = 0
                            AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                ";
                $id = $db->getOne($sql, true);
                $seedContact = new Contact();
                $seedContact->retrieve($id);

                if(!empty($seedContact->id)) {
                    // Если Контакт был корректно найден

                    // Данные по Контакту
                    $contact_smarty['ID'] = $seedContact->id;
                    $contact_smarty['NAME'] = $seedContact->full_name;
                    $contact_smarty['ASSIGNED_USER_NAME'] = $seedContact->assigned_user_name;
                    $contact_smarty['emails'] = [];
                    $emailAdresses = $seedContact->emailAddress->addresses;
                    foreach ($emailAdresses as $emailAdress) {
                        $contact_smarty['emails'][] = [
                            'NAME' => $emailAdress['email_address'],
                            'PRIMARY' => $emailAdress['primary_address'],
                            'INVALID' => $emailAdress['invalid_email'],
                        ];
                    }


                    // Поля для правки данных
                    $contact_fields_smarty = getFields($seedContact);

                    // Находим Контрагента для Контакта
                    $seedAccount = new Account();
                    $seedAccount->retrieve($seedContact->account_id);

                    if(!empty($seedAccount->id)) {
                        // Если Контрагент для Контакта успешно найден
                        $account_smarty['ID'] = $seedAccount->id;
                        $account_smarty['NAME'] = $seedAccount->name;
                    }

                    // Находим Activities

                    // Tasks
                    $sql = "
                            SELECT
                                `id`
                            FROM
                                `tasks`
                            WHERE
                                `deleted` = 0
                                AND (
                                    `parent_type` = 'Contacts'
                                    AND `parent_id` = '{$seedContact->id}'
                                    ) OR (
                                    `parent_type` = 'Accounts'
                                    AND `parent_id` = '{$seedAccount->id}'
                                    AND `parent_id` IS NOT NULL
                                    AND `parent_id` != ''
                                    )
                            ORDER BY
                                `date_due` DESC
                    ";
                    $result = $db->query($sql, true);
                    while ($row = $db->fetchByAssoc($result)) {
                        // Разбираем очередную Задачку Контакта
                        $seedTask = new Task();
                        $seedTask->retrieve($row['id']);
                        if(!empty($seedTask->id)) {
                            // Если Задача коррректно найдена
                            if(in_array($seedTask->status, ['Completed','Deferred'])) {
                                // У Задачи выполненный статус
                                $history_smarty[$seedTask->id] = [
                                    'TYPE' => 'Tasks',
                                    'ID' => $seedTask->id,
                                    'NAME' => $seedTask->name,
                                    'ASSIGNED_USER_NAME' => $seedTask->assigned_user_name,
                                    'STATUS' => $seedTask->status,
                                    'STATUS_STRING' => isset($app_list_strings[$seedBean->field_name_map['status']['options']][$seedTask->status]) ? $app_list_strings[$seedBean->field_name_map['status']['options']][$seedTask->status] : $seedTask->status,
                                    'DATE' => $seedTask->date_due,
                                ];

                                // Получаем редактируемые поля для Задачи



                            } else {
                                // Задача в рабочем статусе
                                $activities_smarty[] = [
                                    'TYPE' => 'Tasks',
                                    'ID' => $seedTask->id,
                                    'NAME' => $seedTask->name,
                                    'ASSIGNED_USER_NAME' => $seedTask->assigned_user_name,
                                    'DATE' => $seedTask->date_due,
                                    'STATUS' => $seedTask->status,
                                    'STATUS_STRING' => isset($app_list_strings[$seedTask->field_name_map['status']['options']][$seedTask->status]) ? $app_list_strings[$seedTask->field_name_map['status']['options']][$seedTask->status] : $seedTask->status,
                                ];
                            }

                        }
                    }

                    // Calls
                    $sql = "
                            SELECT
                                `id`
                            FROM
                                `calls`
                            WHERE
                                `deleted` = 0
                                AND (
                                    `parent_type` = 'Contacts'
                                    AND `parent_id` = '{$seedContact->id}'
                                    ) OR (
                                    `parent_type` = 'Accounts'
                                    AND `parent_id` = '{$seedAccount->id}'
                                    AND `parent_id` IS NOT NULL
                                    AND `parent_id` != ''
                                    )
                            ORDER BY
                                `date_start` DESC
                    ";
                    $result = $db->query($sql, true);
                    while ($row = $db->fetchByAssoc($result)) {
                        // Разбираем очередной Звонок Контакта
                        $seedCall = new Call();
                        $seedCall->retrieve($row['id']);
                        if(!empty($seedCall->id)) {
                            // Если Звонок коррректно найден
                            if(in_array($seedCall->status, ['Planned'])) {
                                // Звонок запланирован
                                $activities_smarty[] = [
                                    'TYPE' => 'Calls',
                                    'ID' => $seedCall->id,
                                    'NAME' => $seedCall->name,
                                    'ASSIGNED_USER_NAME' => $seedCall->assigned_user_name,
                                    'DATE' => $seedCall->date_start,
                                    'STATUS' => $seedCall->status,
                                    'STATUS_STRING' => isset($app_list_strings[$seedBean->field_name_map['status']['options']][$seedCall->status]) ? $app_list_strings[$seedBean->field_name_map['status']['options']][$seedCall->status] : $seedCall->status,
                                ];

                            } else {
                                // Звонок состоялся
                                $history_smarty[$seedCall->id] = [
                                    'TYPE' => 'Calls',
                                    'ID' => $seedCall->id,
                                    'NAME' => $seedCall->name,
                                    'ASSIGNED_USER_NAME' => $seedCall->assigned_user_name,
                                    'STATUS' => $seedCall->status,
                                    'STATUS_STRING' => isset($app_list_strings[$seedBean->field_name_map['status']['options']][$seedCall->status]) ? $app_list_strings[$seedBean->field_name_map['status']['options']][$seedCall->status] : $seedCall->status,
                                    'DATE' => $seedCall->date_start,
                                ];

                            }

                        }
                    }

                    // Meetings
                    $sql = "
                            SELECT
                                `id`
                            FROM
                                `meetings`
                            WHERE
                                `deleted` = 0
                                AND (
                                    `parent_type` = 'Contacts'
                                    AND `parent_id` = '{$seedContact->id}'
                                    ) OR (
                                    `parent_type` = 'Accounts'
                                    AND `parent_id` = '{$seedAccount->id}'
                                    AND `parent_id` IS NOT NULL
                                    AND `parent_id` != ''
                                    )
                            ORDER BY
                                `date_start` DESC
                    ";
                    $result = $db->query($sql, true);
                    while ($row = $db->fetchByAssoc($result)) {
                        // Разбираем очередную Встречу Контакта
                        $seedMeeting = new Meeting();
                        $seedMeeting->retrieve($row['id']);
                        if(!empty($seedMeeting->id)) {
                            // Если Встреча корректно найдена
                            if(in_array($seedMeeting->status, ['Planned'])) {
                                // Встреча запланирована
                                $activities_smarty[] = [
                                    'TYPE' => $seedMeeting->module_dir,
                                    'ID' => $seedMeeting->id,
                                    'NAME' => $seedMeeting->name,
                                    'ASSIGNED_USER_NAME' => $seedMeeting->assigned_user_name,
                                    'DATE' => $seedMeeting->date_start,
                                    'STATUS' => $seedMeeting->status,
                                    'STATUS_STRING' => isset($app_list_strings[$seedBean->field_name_map['status']['options']][$seedMeeting->status]) ? $app_list_strings[$seedBean->field_name_map['status']['options']][$seedMeeting->status] : $seedMeeting->status,
                                ];

                            } else {
                                // Встреча состоялась
                                $history_smarty[$seedMeeting->id] = [
                                    'TYPE' => $seedMeeting->module_dir,
                                    'ID' => $seedMeeting->id,
                                    'NAME' => $seedMeeting->name,
                                    'ASSIGNED_USER_NAME' => $seedMeeting->assigned_user_name,
                                    'STATUS' => $seedMeeting->status,
                                    'STATUS_STRING' => isset($app_list_strings[$seedBean->field_name_map['status']['options']][$seedMeeting->status]) ? $app_list_strings[$seedBean->field_name_map['status']['options']][$seedMeeting->status] : $seedMeeting->status,
                                    'DATE' => $seedMeeting->date_start,
                                ];
                            }

                        }
                    }

                    // Emails
                    $sql = "
                            SELECT
                                `id`
                            FROM
                                `emails`
                            WHERE
                                `deleted` = 0
                                AND (
                                    `parent_type` = 'Contacts'
                                    AND `parent_id` = '{$seedContact->id}'
                                    ) OR (
                                    `parent_type` = 'Accounts'
                                    AND `parent_id` = '{$seedAccount->id}'
                                    AND `parent_id` IS NOT NULL
                                    AND `parent_id` != ''
                                    )
                            ORDER BY
                                `date_sent` DESC
                    ";
                    $result = $db->query($sql, true);
                    while ($row = $db->fetchByAssoc($result)) {
                        // Разбираем очередный Email Контакта
                        $seedEmail = new Email();
                        $seedEmail->retrieve($row['id']);
                        if(!empty($seedEmail->id)) {
                            // Если Встреча корректно найдена
                            $history_smarty[$seedEmail->id] = [
                                'TYPE' => $seedEmail->module_dir,
                                'ID' => $seedEmail->id,
                                'NAME' => $seedEmail->name,
                                'ASSIGNED_USER_NAME' => $seedEmail->assigned_user_name,
                                'STATUS' => $seedEmail->status,
                                'STATUS_STRING' => isset($app_list_strings[$seedBean->field_name_map['status']['options']][$seedEmail->status]) ? $app_list_strings[$seedBean->field_name_map['status']['options']][$seedEmail->status] : $seedEmail->status,
                                'DATE' => $seedEmail->date_sent,
                            ];
                        }
                    }


                    // Notes
                    $sql = "
                            SELECT
                                `id`
                            FROM
                                `notes`
                            WHERE
                                `deleted` = 0
                                AND (
                                    `parent_type` = 'Contacts'
                                    AND `parent_id` = '{$seedContact->id}'
                                    ) OR (
                                    `parent_type` = 'Accounts'
                                    AND `parent_id` = '{$seedAccount->id}'
                                    AND `parent_id` IS NOT NULL
                                    AND `parent_id` != ''
                                    )
                            ORDER BY
                                `date_entered` DESC
                    ";
                    $result = $db->query($sql, true);
                    while ($row = $db->fetchByAssoc($result)) {
                        // Разбираем очередную Заметку Контакта
                        $seedNote = new Note();
                        $seedNote->retrieve($row['id']);
                        if(!empty($seedNote->id)) {
                            // Если Зазметка корректно найдена
                            $history_smarty[$seedNote->id] = [
                                'TYPE' => $seedNote->module_dir,
                                'ID' => $seedNote->id,
                                'NAME' => $seedNote->name,
                                'ASSIGNED_USER_NAME' => $seedNote->assigned_user_name,
                                'STATUS' => '',
                                'STATUS_STRING' => '',
                                'DATE' => $seedNote->date_entered,
                            ];
                        }
                    }


                    // Находим Сделки
                    $sql = "
                            SELECT
                                `opportunities`.`id`
                            FROM
                                `opportunities`
                            INNER JOIN
                                `opportunities_contacts`
                                ON `opportunities_contacts`.`opportunity_id` = `opportunities`.`id`
                                AND `opportunities_contacts`.`deleted` = 0
                                AND `opportunities_contacts`.`contact_id` = '{$seedContact->id}'
                            WHERE
                                `opportunities`.`deleted` = 0
                            ORDER BY
                                `opportunities`.`date_closed` DESC
                    ";
                    $result = $db->query($sql, true);
                    while ($row = $db->fetchByAssoc($result)) {
                        // Получаем данные по очередной Сделке
                        $seedOpportunity = new Opportunity();
                        $seedOpportunity->retrieve($row['id']);
                        if(!empty($seedOpportunity->id)) {
                            // Если Сделка коррректно найдена
                            $opportunities_smarty[$seedOpportunity->id] = [
                                'ID' => $seedOpportunity->id,
                                'NAME' => $seedOpportunity->name,
                                'ASSIGNED_USER_NAME' => $seedOpportunity->assigned_user_name,
                                'SALES_STAGE' => $seedOpportunity->sales_stage,
                                'SALES_STAGE_STRING' => isset($app_list_strings[$seedOpportunity->field_name_map['sales_stage']['options']][$seedOpportunity->sales_stage]) ? $app_list_strings[$seedOpportunity->field_name_map['sales_stage']['options']][$seedOpportunity->sales_stage] : $seedOpportunity->sales_stage,
                            ];

                        }
                    }


                    // Сортировка Activities
                    usort($activities_smarty, function($a, $b){
                        if(strtotime($a['DATE']) > strtotime($b['DATE'])) {
                            return -1;
                        } elseif (strtotime($a['DATE']) < strtotime($b['DATE'])) {
                            return 1;
                        }
                        return 0;
                    });

                    // Сортировка History
                    usort($history_smarty, function($a, $b){
                        if(strtotime($a['DATE']) > strtotime($b['DATE'])) {
                            return -1;
                        } elseif (strtotime($a['DATE']) < strtotime($b['DATE'])) {
                            return 1;
                        }
                        return 0;
                    });

                    //print_array($activities_smarty);
                    //print_array($opportunities_smarty);

                    $smarty->assign("SITE_URL", $sugar_config['site_url']);
                    $smarty->assign("ACTION", 'getContactInfo');
                    $smarty->assign("contact", $contact_smarty);
                    $smarty->assign("account", $account_smarty);
                    $smarty->assign("activities", $activities_smarty);
                    $smarty->assign("history_items", $history_smarty);
                    $smarty->assign("opportunities", $opportunities_smarty);
                    $smarty->assign("contact_fields", $contact_fields_smarty);
                    $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.getContactInfo.tpl');
                    $smarty->assign("RND", $_REQUEST['rnd']);
                    $smarty->assign("TOKEN", $_REQUEST['token']);
                    $smarty->assign("LANG", $GLOBALS['current_language']);

                    $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");


                } else {
                    // Контакт по переданному Email не найден

                    // Попытка найти Контактов, подходящих для указанного ненайденного Email

                    $domain = '';
                    if(!empty($_REQUEST['email'])) {
                        // Домен почты
                        $email_array = explode("@", $_REQUEST['email']);
                        $domain = $email_array[1];
                    }

                    // Контакты, у которых емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                                SELECT
                                    `contacts`.`id`
                                FROM
                                    `contacts`
                                INNER JOIN
                                    `email_addr_bean_rel`
                                    ON `email_addr_bean_rel`.`bean_id` = `contacts`.`id`
                                    AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                                    AND `email_addr_bean_rel`.`deleted` = 0
                                INNER JOIN
                                    `email_addresses`
                                    ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                                    AND `email_addresses`.`deleted` = 0
                                    AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                                WHERE
                                    `contacts`.`deleted` = 0
                        ";
                        //print_array($sql);
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedContact = new Contact();
                            $seedContact->retrieve($row['id']);
                            if(!empty($seedContact->id) AND !isset($contacts_smarty[$seedContact->id])) {
                                // Если Контакт корректно найден
                                $contacts_smarty[$seedContact->id] = [
                                    'ID' => $seedContact->id,
                                    'FULL_NAME' => $seedContact->full_name,
                                    'EMAIL1' => $seedContact->email1,
                                    'EMAIL2' => $seedContact->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контакты, присутствующие у Контрагента, имеющего заданный домен
                    if($domain != '') {
                        $sql = "
                                SELECT
                                    `contacts`.`id`
                                FROM
                                    `contacts`
                                INNER JOIN
                                    `accounts_contacts`
                                    ON `accounts_contacts`.`contact_id` = `contacts`.`id`
                                    AND `accounts_contacts`.`deleted` = 0
                                INNER JOIN
                                    `accounts`
                                    ON `accounts`.`id` = `accounts_contacts`.`account_id`
                                    AND `accounts`.`deleted` = 0
                                    AND `accounts`.`website` LIKE '%".strtoupper($domain)."%'
                                WHERE
                                    `contacts`.`deleted` = 0
                        ";
                        //print_array($sql);
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedContact = new Contact();
                            $seedContact->retrieve($row['id']);
                            if(!empty($seedContact->id) AND !isset($contacts_smarty[$seedContact->id])) {
                                // Если Контакт корректно найден
                                $contacts_smarty[$seedContact->id] = [
                                    'ID' => $seedContact->id,
                                    'FULL_NAME' => $seedContact->full_name,
                                    'EMAIL1' => $seedContact->email1,
                                    'EMAIL2' => $seedContact->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контакты, присутствующие у Контрагента, имеющего Email в искомом домене
                    if($domain != '') {
                        $sql = "
                                SELECT
                                    `contacts`.`id`
                                FROM
                                    `contacts`
                                INNER JOIN
                                    `accounts_contacts`
                                    ON `accounts_contacts`.`contact_id` = `contacts`.`id`
                                    AND `accounts_contacts`.`deleted` = 0
                                INNER JOIN
                                    `accounts`
                                    ON `accounts`.`id` = `accounts_contacts`.`account_id`
                                    AND `accounts`.`deleted` = 0
                                INNER JOIN
                                    `email_addr_bean_rel`
                                    ON `email_addr_bean_rel`.`bean_id` = `accounts`.`id`
                                    AND `email_addr_bean_rel`.`bean_module` = 'Accounts'
                                    AND `email_addr_bean_rel`.`deleted` = 0
                                INNER JOIN
                                    `email_addresses`
                                    ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                                    AND `email_addresses`.`deleted` = 0
                                    AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                                WHERE
                                    `contacts`.`deleted` = 0
                        ";
                        //print_array($sql);
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedContact = new Contact();
                            $seedContact->retrieve($row['id']);
                            if(!empty($seedContact->id) AND !isset($contacts_smarty[$seedContact->id])) {
                                // Если Контакт корректно найден
                                $contacts_smarty[$seedContact->id] = [
                                    'ID' => $seedContact->id,
                                    'FULL_NAME' => $seedContact->full_name,
                                    'EMAIL1' => $seedContact->email1,
                                    'EMAIL2' => $seedContact->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    $smarty->assign("SITE_URL", $sugar_config['site_url']);
                    $smarty->assign("ACTION", 'unknownEmail');
                    $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.unknownEmail.tpl');
                    $smarty->assign("RND", $_REQUEST['rnd']);
                    $smarty->assign("TOKEN", $_REQUEST['token']);
                    $smarty->assign("EMAIL", $_REQUEST['email']);
                    $smarty->assign("FROMNAME", $_REQUEST['fromName']);
                    $smarty->assign("LANG", $GLOBALS['current_language']);
                    $smarty->assign("contacts", $contacts_smarty);

                    $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");
                }
            }


            break;


        case 'setNewValue':
            // Сохранение нового значения

            $return_array = [
                'status' => 'error',
            ];
            if(isset($_REQUEST['module']) AND isset($_REQUEST['record'])) {
                $seedBean = BeanFactory::getBean($_REQUEST['module'], $_REQUEST['record']);
                if(!empty($seedBean->id)) {
                    // Если запись корректно найдена
                    if(ACLController::checkAccess($_REQUEST['module'], 'edit', true) AND isset($_REQUEST['field']) AND isset($_REQUEST['newValue'])) {
                        // Если доступ на правку разрешен
                        // И передано название поля и его новое значение
                        $seedBean->retrieve($seedBean->id);
                        $fieldName = $_REQUEST['field'];

                        $fieldEditAccess = false;


                        if(in_array($fieldName, $GLOBALS['editFields'][$_REQUEST['module']]) AND isset($seedBean->field_name_map[$fieldName])) {
                            // Если поле есть среди полей модуля
                            $seedBean->$fieldName = $_REQUEST['newValue'];
                            $seedBean->save();
                            $return_array = [
                                'status' => 'ok',
                            ];
                        }

                    }
                }
            }

            $json = new JSON();
            echo $json->encode($return_array);
            exit;

            break;

        case 'selectAccountsForDatalist':
            // Получение списка Контрагентов по запросу

            $return_array = [];
            $sql = "SELECT `id`,`name` FROM `accounts` WHERE `deleted` = 0 AND `name` LIKE '%{$_REQUEST['keyword']}%' ORDER BY `name` ASC";
            $result = $db->query($sql, true);
            while ($row = $db->fetchByAssoc($result)) {
                $return_array[] = [
                    'id' => $row['id'],
                    'name' => $row['name'],
                ];
            }

            echo json_encode($return_array);
            exit;
            break;


        case 'selectContactsForDatalist':
            // Получение списка Контактов по запросу
            $return_array = [];
            $sql = "SELECT `id`,`first_name`,`last_name` FROM `contacts` WHERE `deleted` = 0 AND (`first_name` LIKE '%{$_REQUEST['keyword']}%' OR `last_name` LIKE '%{$_REQUEST['keyword']}%') ORDER BY `last_name`,`first_name` ASC";
            $result = $db->query($sql, true);
            while ($row = $db->fetchByAssoc($result)) {
                $return_array[] = [
                    'id' => $row['id'],
                    'full_name' => $row['last_name'] . ' ' . $row['first_name'],
                ];
            }

            echo json_encode($return_array);
            exit;
            break;


        case 'addTaskForContact':
            // Страница добавления новой Задачи
            $smarty = new Sugar_Smarty();

            $contact_smarty = [];
            $accounts_smarty = [];

            if(isset($_REQUEST['contact_id'])) {
                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Данные по Контакту
                    $contact_smarty['ID'] = $seedContact->id;
                    $contact_smarty['NAME'] = $seedContact->full_name;
                    $contact_smarty['EMAIL'] = $seedContact->email1;
                    $contact_smarty['ASSIGNED_USER_NAME'] = $seedContact->assigned_user_name;

                    // Находим Контрагента для Контакта
                    $seedAccount = new Account();
                    $seedAccount->retrieve($seedContact->account_id);

                    if(!empty($seedAccount->id)) {
                        // Если Контрагент для Контакта успешно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $seedAccount->email1,
                            'EMAIL2' => $seedAccount->email2,
                            'SELECTED' => true,
                        ];
                    }

                    // Попытка найти Контрагентов, подходящих для текущего Контакта

                    $domains = [];
                    if(!empty($seedContact->email1)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }
                    if(!empty($seedContact->email2)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }

                    $domains = array_unique($domains);

                    // Контрагенты, у которых есть такой домен
                    foreach ($domains as $domain) {
                        $sql = "SELECT `id` FROM `accounts` WHERE `deleted` = 0 AND `website` LIKE '%{$domain}'";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`
                        FROM
                            `accounts`
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `accounts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Accounts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых есть Контакты с емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`,
                            `email_addresses`.`email_address`
                        FROM
                            `accounts`
                        INNER JOIN
                            `accounts_contacts`
                            ON `accounts_contacts`.`account_id` = `accounts`.`id`
                            AND `accounts_contacts`.`deleted` = 0
                        INNER JOIN
                            `contacts`
                            ON `contacts`.`id` = `accounts_contacts`.`contact_id`
                            AND `contacts`.`deleted` = 0
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `contacts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $row['email_address'],
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }




                }
            }

            // Поля для редактирования
            $seedTask = new Task();
            $fields_smarty = getFields($seedTask, 'new');
            $mod_strings = return_module_language($current_language, $seedTask->module_dir);

            // Формат даты
            $dateFormat = $timedate->get_user_date_format();
            $dateFormat = str_replace("yyyy", 'yy', $dateFormat);


            $smarty->assign("SITE_URL", $sugar_config['site_url']);
            $smarty->assign("ACTION", $_REQUEST['action']);
            $smarty->assign("contact", $contact_smarty);
            $smarty->assign("accounts", $accounts_smarty);
            $smarty->assign("fields", $fields_smarty);
            $smarty->assign("CALENDAR_FORMAT", $dateFormat);
            $smarty->assign('CALENDAR_FDOW', $current_user->get_first_day_of_week());
            $smarty->assign('TIME_SEPARATOR', ':');
            $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.' . $_REQUEST['action'] . '.tpl');
            $smarty->assign("RND", $_REQUEST['rnd']);
            $smarty->assign("TOKEN", $_REQUEST['token']);
            $smarty->assign("MOD", $mod_strings);
            $smarty->assign("LANG", $GLOBALS['current_language']);

            $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");

            break;


        case 'saveTaskForContact':
            // Сохранение новой Задачи для Контакта

            if(isset($_REQUEST['contact_id'])) {
                // Если был передан Контакт

                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    $seedTask = new Task();
                    $seedTask->name = $_REQUEST['name'];
                    $seedTask->description = $_REQUEST['description'];
                    $seedTask->priority = $_REQUEST['priority'];
                    $seedTask->assigned_user_id = $_REQUEST['assigned_user_id'];
                    $seedTask->contact_id = $seedContact->id;

                    // Обрабатываем привязку к Контрагенту
                    if(isset($_REQUEST['account_select'])) {
                        // Если Контрагента в принципе какого то выбрали
                        if($_REQUEST['account_select'] == 'other') {
                            // Был выбран пункт создания нового Контрагента
                            if(isset($_REQUEST['account_id']) AND $_REQUEST['account_id'] != '') {
                                // Если был найден и выбран Контрагент
                                $seedAccount = new Account();
                                $seedAccount->retrieve($_REQUEST['account_id']);
                                if(!empty($seedAccount->id)) {
                                    // Если Контрагент корректно найден

                                    if($seedAccount->name == $_REQUEST['account_name']) {
                                        // Добавляем связь Контрагента и Контакта
                                        $seedTask->parent_type = 'Accounts';
                                        $seedTask->parent_id = $seedAccount->id;
                                    } else {
                                        // Был в итоге выбран другой Контрагент
                                        $seedAccount = new Account();
                                        $seedAccount->name = $_REQUEST['account_name'];
                                        $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                        $seedAccount->save();

                                        // Добавляем связь Контрагента и Контакта
                                        $seedTask->parent_type = 'Accounts';
                                        $seedTask->parent_id = $seedAccount->id;

                                    }

                                }

                            } elseif(isset($_REQUEST['account_name']) AND $_REQUEST['account_name'] != '') {
                                // Было указано название Контрагента
                                $seedAccount = new Account();
                                $seedAccount->name = $_REQUEST['account_name'];
                                $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                $seedAccount->save();

                                // Добавляем связь Контрагента и Контакта
                                $seedTask->parent_type = 'Accounts';
                                $seedTask->parent_id = $seedAccount->id;

                            }
                        } else {
                            // Выл указан пункт выбора предопределенного значения ранее найденного и предложенного Контрагента
                            $seedAccount = new Account();
                            $seedAccount->retrieve($_REQUEST['account_select']);
                            if(!empty($seedAccount->id)) {
                                // Если Контрагент корректно найден

                                // Добавляем связь Контрагента и Контакта
                                $seedTask->parent_type = 'Accounts';
                                $seedTask->parent_id = $seedAccount->id;
                            }
                        }
                    }

                    if(empty($seedTask->parent_type)) {
                        // Если родительский объект не был указан
                        // Прикрепляем задачу к Контакту
                        $seedTask->parent_type = 'Contacts';
                        $seedTask->parent_id = $seedContact->id;
                    }

                    // Date Start
                    $date_time_array = explode(" ", $_REQUEST['date_start']);
                    if(isset($date_time_array[1]) AND strlen($date_time_array[1]) == 4) {
                        // Есть время, отделенное пробелом, без двоеточия слитно
                        $seedTask->date_start = $date_time_array[0] . ' ' . substr($date_time_array[1], 0, 2) . ':' . substr($date_time_array[1], 2, 2);
                    } else {
                        $seedTask->date_start = $_REQUEST['date_start'];
                    }

                    // Date Due
                    $date_time_array = explode(" ", $_REQUEST['date_due']);
                    if(isset($date_time_array[1]) AND strlen($date_time_array[1]) == 4) {
                        // Есть время, отделенное пробелом, без двоеточия слитно
                        $seedTask->date_due = $date_time_array[0] . ' ' . substr($date_time_array[1], 0, 2) . ':' . substr($date_time_array[1], 2, 2);
                    } else {
                        $seedTask->date_due = $_REQUEST['date_due'];
                    }


                    $seedTask->save();

                    // Отправляем на страницу просмотра Контакта
                    $url = "?entryPoint=chromeMailExtension&rnd=".$_REQUEST['rnd']."&token=".$_REQUEST['token']."&action=showInfoForEmail&email=" . $seedContact->email1;
                    header("Location: " . $url);
                    exit;
                }

            }

            break;



        case 'addEmailToContact':
            // Присоединение EMail к выбранному Контакту
            if(isset($_REQUEST['baseEmail'])) {
                // Если Емайл вообще передан

                // Определяем Контакт
                $seedContact = new Contact();
                if(isset($_REQUEST['contact_select']) AND $_REQUEST['contact_select'] != '' AND $_REQUEST['contact_select'] != 'other') {
                    // Если пришло выбранное значение ID Контакта
                    $seedContact->retrieve($_REQUEST['contact_select']);
                }
                elseif (isset($_REQUEST['contact_select']) AND $_REQUEST['contact_select'] == 'other' AND isset($_REQUEST['contact_id']) AND $_REQUEST['contact_id'] != '') {
                    $seedContact->retrieve($_REQUEST['contact_id']);
                }

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Добавляем в Контакт указанный Email
                    $seedContact->emailAddress->addAddress($_REQUEST['baseEmail']);
                    $seedContact->emailAddress->saveEmail($seedContact->id, $seedContact->module_dir, [$_REQUEST['baseEmail']]);
                }

            }

            // Отправляем на первоначальную главную страницу
            $url = "?entryPoint=chromeMailExtension&rnd=".$_REQUEST['rnd']."&token=".$_REQUEST['token']."&action=showInfoForEmail&email=" . $_REQUEST['baseEmail'];
            header("Location: " . $url);

            break;


        case 'addContact':
            // Страница добавления нового Контакта
            $smarty = new Sugar_Smarty();

            $seedContact = new Contact();
            $seedContact->first_name = $_REQUEST['fromName'];
            $seedContact->email1 = $_REQUEST['email'];

            $contact_smarty = [];
            $accounts_smarty = [];

            $contact_smarty['EMAIL'] = $_REQUEST['email'];

            // Поля для редактирования
            $fields_smarty = getFields($seedContact, 'new');

            // Формат даты
            $dateFormat = $timedate->get_user_date_format();
            $dateFormat = str_replace("yyyy", 'yy', $dateFormat);

            // Попытка найти Контрагентов, подходящих для текущего Контакта

            // Домен почты
            $email_array = explode("@", $_REQUEST['email']);
            $domain = $email_array[1];

            // Контрагенты, у которых есть такой домен
            if($domain != '') {
                $sql = "SELECT `id` FROM `accounts` WHERE `deleted` = 0 AND `website` LIKE '%{$domain}'";
                $result = $db->query($sql, true);
                while ($row = $db->fetchByAssoc($result)) {
                    $seedAccount = new Account();
                    $seedAccount->retrieve($row['id']);
                    if(!empty($seedAccount->id)) {
                        // Если Контрагент корректно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $seedAccount->email1,
                            'EMAIL2' => $seedAccount->email2,
                        ];
                    }
                }
            }

            // Контрагенты, у которых емайл в заданном домене
            if($domain != '') {
                $sql = "
                        SELECT
                            `accounts`.`id`
                        FROM
                            `accounts`
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `accounts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Accounts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                $result = $db->query($sql, true);
                while ($row = $db->fetchByAssoc($result)) {
                    $seedAccount = new Account();
                    $seedAccount->retrieve($row['id']);
                    if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                        // Если Контрагент корректно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $seedAccount->email1,
                            'EMAIL2' => $seedAccount->email2,
                        ];
                    }
                }
            }

            // Контрагенты, у которых есть Контакты с емайл в заданном домене
            if($domain != '') {
                $sql = "
                        SELECT
                            `accounts`.`id`,
                            `email_addresses`.`email_address`
                        FROM
                            `accounts`
                        INNER JOIN
                            `accounts_contacts`
                            ON `accounts_contacts`.`account_id` = `accounts`.`id`
                            AND `accounts_contacts`.`deleted` = 0
                        INNER JOIN
                            `contacts`
                            ON `contacts`.`id` = `accounts_contacts`.`contact_id`
                            AND `contacts`.`deleted` = 0
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `contacts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                $result = $db->query($sql, true);
                while ($row = $db->fetchByAssoc($result)) {
                    $seedAccount = new Account();
                    $seedAccount->retrieve($row['id']);
                    if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                        // Если Контрагент корректно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $row['email_address'],
                        ];
                    }
                }
            }

            $smarty->assign("SITE_URL", $sugar_config['site_url']);
            $smarty->assign("ACTION", $_REQUEST['action']);
            $smarty->assign("contact", $contact_smarty);
            $smarty->assign("accounts", $accounts_smarty);
            $smarty->assign("fields", $fields_smarty);
            $smarty->assign("CALENDAR_FORMAT", $dateFormat);
            $smarty->assign('CALENDAR_FDOW', $current_user->get_first_day_of_week());
            $smarty->assign('TIME_SEPARATOR', ':');
            $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.' . $_REQUEST['action'] . '.tpl');
            $smarty->assign("RND", $_REQUEST['rnd']);
            $smarty->assign("TOKEN", $_REQUEST['token']);
            $smarty->assign("LANG", $GLOBALS['current_language']);

            $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");

            break;

        case 'saveContact':
            // Пришли данные с формы сохранения Контакта

            //print_array($_REQUEST,1);

            $seedContact = new Contact();
            $fields = $GLOBALS['newFields']['Contacts'];
            if(!in_array('assigned_user_id', $fields)) {
                // Добавляем поле с ID ответственного
                $fields[] = 'assigned_user_id';
            }
            foreach ($fields as $fieldName) {
                $seedContact->$fieldName = $_REQUEST[$fieldName];
            }
            $seedContact->save();

            // Обрабатываем привязку к Контрагенту
            if(isset($_REQUEST['account_select'])) {
                // Если Контрагента в принципе какого то выбрали
                if($_REQUEST['account_select'] == 'other') {
                    // Был выбран пункт создания нового Контрагента
                    if(isset($_REQUEST['account_id']) AND $_REQUEST['account_id'] != '') {
                        // Если был найден и выбран Контрагент
                        $seedAccount = new Account();
                        $seedAccount->retrieve($_REQUEST['account_id']);
                        if(!empty($seedAccount->id)) {
                            // Если Контрагент корректно найден

                            if($seedAccount->name == $_REQUEST['account_name']) {
                                // Добавляем связь Контрагента и Контакта
                                $seedAccount->load_relationship("contacts");
                                $seedAccount->contacts->add($seedContact->id);
                            } else {
                                // Был в итоге выбран другой Контрагент
                                $seedAccount = new Account();
                                $seedAccount->name = $_REQUEST['account_name'];
                                $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                $seedAccount->save();

                                // Добавляем связь Контрагента и Контакта
                                $seedAccount->load_relationship("contacts");
                                $seedAccount->contacts->add($seedContact->id);

                            }

                        }

                    } elseif(isset($_REQUEST['account_name']) AND $_REQUEST['account_name'] != '') {
                        // Было указано название Контрагента
                        $seedAccount = new Account();
                        $seedAccount->name = $_REQUEST['account_name'];
                        $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                        $seedAccount->save();

                        // Добавляем связь Контрагента и Контакта
                        $seedAccount->load_relationship("contacts");
                        $seedAccount->contacts->add($seedContact->id);

                    }
                } else {
                    // Выл указан пункт выбора предопределенного значения ранее найденного и предложенного Контрагента
                    $seedAccount = new Account();
                    $seedAccount->retrieve($_REQUEST['account_select']);
                    if(!empty($seedAccount->id)) {
                        // Если Контрагент корректно найден

                        // Добавляем связь Контрагента и Контакта
                        $seedAccount->load_relationship("contacts");
                        $seedAccount->contacts->add($seedContact->id);
                    }
                }
            }

            // Отправляем на страницу просмотра Контакта
            $url = "?entryPoint=chromeMailExtension&rnd=".$_REQUEST['rnd']."&token=".$_REQUEST['token']."&action=showInfoForEmail&email=" . $seedContact->email1;
            header("Location: " . $url);
            exit;
            break;

        case 'addNoteForContact':
            // Страница добавления новой Заметки
            $smarty = new Sugar_Smarty();

            $contact_smarty = [];
            $accounts_smarty = [];

            if(isset($_REQUEST['contact_id'])) {
                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Данные по Контакту
                    $contact_smarty['ID'] = $seedContact->id;
                    $contact_smarty['NAME'] = $seedContact->full_name;
                    $contact_smarty['EMAIL'] = $seedContact->email1;
                    $contact_smarty['ASSIGNED_USER_NAME'] = $seedContact->assigned_user_name;

                    // Находим Контрагента для Контакта
                    $seedAccount = new Account();
                    $seedAccount->retrieve($seedContact->account_id);

                    if(!empty($seedAccount->id)) {
                        // Если Контрагент для Контакта успешно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $seedAccount->email1,
                            'EMAIL2' => $seedAccount->email2,
                            'SELECTED' => true,
                        ];
                    }

                    // Попытка найти Контрагентов, подходящих для текущего Контакта

                    $domains = [];
                    if(!empty($seedContact->email1)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }
                    if(!empty($seedContact->email2)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }

                    $domains = array_unique($domains);

                    // Контрагенты, у которых есть такой домен
                    foreach ($domains as $domain) {
                        $sql = "SELECT `id` FROM `accounts` WHERE `deleted` = 0 AND `website` LIKE '%{$domain}'";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`
                        FROM
                            `accounts`
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `accounts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Accounts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых есть Контакты с емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`,
                            `email_addresses`.`email_address`
                        FROM
                            `accounts`
                        INNER JOIN
                            `accounts_contacts`
                            ON `accounts_contacts`.`account_id` = `accounts`.`id`
                            AND `accounts_contacts`.`deleted` = 0
                        INNER JOIN
                            `contacts`
                            ON `contacts`.`id` = `accounts_contacts`.`contact_id`
                            AND `contacts`.`deleted` = 0
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `contacts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $row['email_address'],
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }
                }
            }

            // Поля для редактирования
            $seedNote = new Note();
            $fields_smarty = getFields($seedNote, 'new');

            // Формат даты
            $dateFormat = $timedate->get_user_date_format();
            $dateFormat = str_replace("yyyy", 'yy', $dateFormat);


            $smarty->assign("SITE_URL", $sugar_config['site_url']);
            $smarty->assign("ACTION", $_REQUEST['action']);
            $smarty->assign("contact", $contact_smarty);
            $smarty->assign("accounts", $accounts_smarty);
            $smarty->assign("fields", $fields_smarty);
            $smarty->assign("CALENDAR_FORMAT", $dateFormat);
            $smarty->assign('CALENDAR_FDOW', $current_user->get_first_day_of_week());
            $smarty->assign('TIME_SEPARATOR', ':');
            $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.' . $_REQUEST['action'] . '.tpl');
            $smarty->assign("RND", $_REQUEST['rnd']);
            $smarty->assign("TOKEN", $_REQUEST['token']);
            $smarty->assign("LANG", $GLOBALS['current_language']);

            $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");

            break;


        case 'saveNoteForContact':
            // Сохранение новой Заметки для Контакта

            if(isset($_REQUEST['contact_id'])) {
                // Если был передан КОнтакт

                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Обрабатываем привязку к Контрагенту
                    if(isset($_REQUEST['account_select'])) {
                        // Если Контрагента в принципе какого то выбрали
                        if($_REQUEST['account_select'] == 'other') {
                            // Был выбран пункт создания нового Контрагента
                            if(isset($_REQUEST['account_id']) AND $_REQUEST['account_id'] != '') {
                                // Если был найден и выбран Контрагент
                                $seedAccount = new Account();
                                $seedAccount->retrieve($_REQUEST['account_id']);
                                if(!empty($seedAccount->id)) {
                                    // Если Контрагент корректно найден

                                    if($seedAccount->name != $_REQUEST['account_name']) {
                                        // Был в итоге выбран другой Контрагент
                                        $seedAccount = new Account();
                                        $seedAccount->name = $_REQUEST['account_name'];
                                        $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                        $seedAccount->save();

                                    }

                                }

                            } elseif(isset($_REQUEST['account_name']) AND $_REQUEST['account_name'] != '') {
                                // Было указано название Контрагента
                                $seedAccount = new Account();
                                $seedAccount->name = $_REQUEST['account_name'];
                                $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                $seedAccount->save();

                            }
                        } else {
                            // Выл указан пункт выбора предопределенного значения ранее найденного и предложенного Контрагента
                            $seedAccount = new Account();
                            $seedAccount->retrieve($_REQUEST['account_select']);
                        }
                    }

                    $seedNote = new Note();
                    $seedNote->name = $_REQUEST['name'];
                    $seedNote->description = $_REQUEST['description'];
                    $seedNote->assigned_user_id = $_REQUEST['assigned_user_id'];
                    if(!empty($seedAccount->id)) {
                        // Если Контрагент явно указан
                        $seedNote->parent_type = 'Accounts';
                        $seedNote->parent_id = $seedAccount->id;
                        $seedNote->contact_id = $seedContact->id;
                    } else {
                        // Контрагента нет
                        $seedNote->parent_type = 'Contacts';
                        $seedNote->parent_id = $seedContact->id;
                    }

                    $seedNote->save();

                    // Отправляем на страницу просмотра Контакта
                    $url = "?entryPoint=chromeMailExtension&rnd=".$_REQUEST['rnd']."&token=".$_REQUEST['token']."&action=showInfoForEmail&email=" . $seedContact->email1;
                    header("Location: " . $url);
                    exit;
                }

            }

            break;

        case 'addCallForContact':
            // Страница добавления нового Звонка
            $smarty = new Sugar_Smarty();

            $contact_smarty = [];
            $accounts_smarty = [];

            if(isset($_REQUEST['contact_id'])) {
                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Данные по Контакту
                    $contact_smarty['ID'] = $seedContact->id;
                    $contact_smarty['NAME'] = $seedContact->full_name;
                    $contact_smarty['EMAIL'] = $seedContact->email1;
                    $contact_smarty['ASSIGNED_USER_NAME'] = $seedContact->assigned_user_name;

                    // Находим Контрагента для Контакта
                    $seedAccount = new Account();
                    $seedAccount->retrieve($seedContact->account_id);

                    if(!empty($seedAccount->id)) {
                        // Если Контрагент для Контакта успешно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $seedAccount->email1,
                            'EMAIL2' => $seedAccount->email2,
                            'SELECTED' => true,
                        ];
                    }

                    // Попытка найти Контрагентов, подходящих для текущего Контакта

                    $domains = [];
                    if(!empty($seedContact->email1)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }
                    if(!empty($seedContact->email2)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }

                    $domains = array_unique($domains);

                    // Контрагенты, у которых есть такой домен
                    foreach ($domains as $domain) {
                        $sql = "SELECT `id` FROM `accounts` WHERE `deleted` = 0 AND `website` LIKE '%{$domain}'";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`
                        FROM
                            `accounts`
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `accounts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Accounts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых есть Контакты с емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`,
                            `email_addresses`.`email_address`
                        FROM
                            `accounts`
                        INNER JOIN
                            `accounts_contacts`
                            ON `accounts_contacts`.`account_id` = `accounts`.`id`
                            AND `accounts_contacts`.`deleted` = 0
                        INNER JOIN
                            `contacts`
                            ON `contacts`.`id` = `accounts_contacts`.`contact_id`
                            AND `contacts`.`deleted` = 0
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `contacts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $row['email_address'],
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }
                }
            }

            // Поля для редактирования
            $seedCall = new Call();
            $fields_smarty = getFields($seedCall, 'new');

            // Формат даты
            $dateFormat = $timedate->get_user_date_format();
            $dateFormat = str_replace("yyyy", 'yy', $dateFormat);


            $smarty->assign("SITE_URL", $sugar_config['site_url']);
            $smarty->assign("ACTION", $_REQUEST['action']);
            $smarty->assign("contact", $contact_smarty);
            $smarty->assign("accounts", $accounts_smarty);
            $smarty->assign("fields", $fields_smarty);
            $smarty->assign("CALENDAR_FORMAT", $dateFormat);
            $smarty->assign('CALENDAR_FDOW', $current_user->get_first_day_of_week());
            $smarty->assign('TIME_SEPARATOR', ':');
            $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.' . $_REQUEST['action'] . '.tpl');
            $smarty->assign("RND", $_REQUEST['rnd']);
            $smarty->assign("TOKEN", $_REQUEST['token']);
            $smarty->assign("LANG", $GLOBALS['current_language']);

            $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");

            break;


        case 'saveCallForContact':
            // Сохранение нового Звонка для Контакта

            if(isset($_REQUEST['contact_id'])) {
                // Если был передан КОнтакт

                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Обрабатываем привязку к Контрагенту
                    if(isset($_REQUEST['account_select'])) {
                        // Если Контрагента в принципе какого то выбрали
                        if($_REQUEST['account_select'] == 'other') {
                            // Был выбран пункт создания нового Контрагента
                            if(isset($_REQUEST['account_id']) AND $_REQUEST['account_id'] != '') {
                                // Если был найден и выбран Контрагент
                                $seedAccount = new Account();
                                $seedAccount->retrieve($_REQUEST['account_id']);
                                if(!empty($seedAccount->id)) {
                                    // Если Контрагент корректно найден

                                    if($seedAccount->name != $_REQUEST['account_name']) {
                                        // Был в итоге выбран другой Контрагент
                                        $seedAccount = new Account();
                                        $seedAccount->name = $_REQUEST['account_name'];
                                        $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                        $seedAccount->save();

                                    }

                                }

                            } elseif(isset($_REQUEST['account_name']) AND $_REQUEST['account_name'] != '') {
                                // Было указано название Контрагента
                                $seedAccount = new Account();
                                $seedAccount->name = $_REQUEST['account_name'];
                                $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                $seedAccount->save();

                            }
                        } else {
                            // Выл указан пункт выбора предопределенного значения ранее найденного и предложенного Контрагента
                            $seedAccount = new Account();
                            $seedAccount->retrieve($_REQUEST['account_select']);
                        }
                    }

                    $seedCall = new Call();
                    $seedCall->name = $_REQUEST['name'];
                    $seedCall->description = $_REQUEST['description'];
                    $seedCall->assigned_user_id = $_REQUEST['assigned_user_id'];
                    $seedCall->duration_hours = $_REQUEST['duration_hours'];
                    $seedCall->duration_minutes = $_REQUEST['duration_minutes'];
                    $seedCall->direction = $_REQUEST['direction'];
                    $seedCall->status = $_REQUEST['status'];

                    // Date Start
                    $date_time_array = explode(" ", $_REQUEST['date_start']);
                    if(isset($date_time_array[1]) AND strlen($date_time_array[1]) == 4) {
                        // Есть время, отделенное пробелом, без двоеточия слитно
                        $seedCall->date_start = $date_time_array[0] . ' ' . substr($date_time_array[1], 0, 2) . ':' . substr($date_time_array[1], 2, 2);
                    } else {
                        $seedCall->date_start = $_REQUEST['date_start'];
                    }

                    if(!empty($seedAccount->id)) {
                        // Если Контрагент явно указан
                        $seedCall->parent_type = 'Accounts';
                        $seedCall->parent_id = $seedAccount->id;
                        $seedCall->contact_id = $seedContact->id;
                    } else {
                        // Контрагента нет
                        $seedCall->parent_type = 'Contacts';
                        $seedCall->parent_id = $seedContact->id;
                    }
                    $seedCall->save();

                    // Добавляем связь с Контактом
                    $seedCall->load_relationship("contacts");
                    $seedCall->contacts->add($seedContact->id);

                    // Отправляем на страницу просмотра Контакта
                    $url = "?entryPoint=chromeMailExtension&rnd=".$_REQUEST['rnd']."&token=".$_REQUEST['token']."&action=showInfoForEmail&email=" . $seedContact->email1;
                    header("Location: " . $url);
                    exit;
                }

            }

            break;

        case 'addOpportunityForContact':
            // Страница добавления новой Сделки
            $smarty = new Sugar_Smarty();

            $contact_smarty = [];
            $accounts_smarty = [];

            if(isset($_REQUEST['contact_id'])) {
                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Данные по Контакту
                    $contact_smarty['ID'] = $seedContact->id;
                    $contact_smarty['NAME'] = $seedContact->full_name;
                    $contact_smarty['EMAIL'] = $seedContact->email1;
                    $contact_smarty['ASSIGNED_USER_NAME'] = $seedContact->assigned_user_name;

                    // Находим Контрагента для Контакта
                    $seedAccount = new Account();
                    $seedAccount->retrieve($seedContact->account_id);

                    if(!empty($seedAccount->id)) {
                        // Если Контрагент для Контакта успешно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $seedAccount->email1,
                            'EMAIL2' => $seedAccount->email2,
                            'SELECTED' => true,
                        ];
                    }

                    // Попытка найти Контрагентов, подходящих для текущего Контакта

                    $domains = [];
                    if(!empty($seedContact->email1)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }
                    if(!empty($seedContact->email2)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }

                    $domains = array_unique($domains);

                    // Контрагенты, у которых есть такой домен
                    foreach ($domains as $domain) {
                        $sql = "SELECT `id` FROM `accounts` WHERE `deleted` = 0 AND `website` LIKE '%{$domain}'";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`
                        FROM
                            `accounts`
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `accounts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Accounts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых есть Контакты с емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`,
                            `email_addresses`.`email_address`
                        FROM
                            `accounts`
                        INNER JOIN
                            `accounts_contacts`
                            ON `accounts_contacts`.`account_id` = `accounts`.`id`
                            AND `accounts_contacts`.`deleted` = 0
                        INNER JOIN
                            `contacts`
                            ON `contacts`.`id` = `accounts_contacts`.`contact_id`
                            AND `contacts`.`deleted` = 0
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `contacts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $row['email_address'],
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                }
            }

            // Поля для редактирования
            $seedOpportunity = new Opportunity();
            $fields_smarty = getFields($seedOpportunity, 'new');

            // Формат даты
            $dateFormat = $timedate->get_user_date_format();
            $dateFormat = str_replace("yyyy", 'yy', $dateFormat);


            $smarty->assign("SITE_URL", $sugar_config['site_url']);
            $smarty->assign("ACTION", $_REQUEST['action']);
            $smarty->assign("contact", $contact_smarty);
            $smarty->assign("accounts", $accounts_smarty);
            $smarty->assign("fields", $fields_smarty);
            $smarty->assign("CALENDAR_FORMAT", $dateFormat);
            $smarty->assign('CALENDAR_FDOW', $current_user->get_first_day_of_week());
            $smarty->assign('TIME_SEPARATOR', ':');
            $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.' . $_REQUEST['action'] . '.tpl');
            $smarty->assign("RND", $_REQUEST['rnd']);
            $smarty->assign("TOKEN", $_REQUEST['token']);
            $smarty->assign("LANG", $GLOBALS['current_language']);

            $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");

            break;


        case 'saveOpportunityForContact':
            // Сохранение нового Звонка для Контакта

            if(isset($_REQUEST['contact_id'])) {
                // Если был передан КОнтакт

                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Обрабатываем привязку к Контрагенту
                    if(isset($_REQUEST['account_select'])) {
                        // Если Контрагента в принципе какого то выбрали
                        if($_REQUEST['account_select'] == 'other') {
                            // Был выбран пункт создания нового Контрагента
                            if(isset($_REQUEST['account_id']) AND $_REQUEST['account_id'] != '') {
                                // Если был найден и выбран Контрагент
                                $seedAccount = new Account();
                                $seedAccount->retrieve($_REQUEST['account_id']);
                                if(!empty($seedAccount->id)) {
                                    // Если Контрагент корректно найден

                                    if($seedAccount->name != $_REQUEST['account_name']) {
                                        // Был в итоге выбран другой Контрагент
                                        $seedAccount = new Account();
                                        $seedAccount->name = $_REQUEST['account_name'];
                                        $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                        $seedAccount->save();

                                    }

                                }

                            } elseif(isset($_REQUEST['account_name']) AND $_REQUEST['account_name'] != '') {
                                // Было указано название Контрагента
                                $seedAccount = new Account();
                                $seedAccount->name = $_REQUEST['account_name'];
                                $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                $seedAccount->save();

                            }
                        } else {
                            // Выл указан пункт выбора предопределенного значения ранее найденного и предложенного Контрагента
                            $seedAccount = new Account();
                            $seedAccount->retrieve($_REQUEST['account_select']);
                        }
                    }

                    $seedOpportunity = new Opportunity();
                    $seedOpportunity->name = $_REQUEST['name'];
                    $seedOpportunity->amount = $_REQUEST['amount'];
                    $seedOpportunity->date_closed = $_REQUEST['date_closed'];
                    $seedOpportunity->description = $_REQUEST['description'];
                    $seedOpportunity->sales_stage = $_REQUEST['sales_stage'];
                    $seedOpportunity->opportunity_type = $_REQUEST['opportunity_type'];
                    $seedOpportunity->lead_source = $_REQUEST['lead_source'];
                    $seedOpportunity->assigned_user_id = $_REQUEST['assigned_user_id'];
                    $seedOpportunity->account_id = $seedAccount->id;
                    $seedOpportunity->contact_id = $seedContact->id;

                    $seedOpportunity->save();

                    // Отправляем на страницу просмотра Контакта
                    $url = "?entryPoint=chromeMailExtension&rnd=".$_REQUEST['rnd']."&token=".$_REQUEST['token']."&action=showInfoForEmail&email=" . $seedContact->email1;
                    header("Location: " . $url);
                    exit;
                }

            }

            break;

        case 'addCaseForContact':
            // Страница добавления нового Обращения
            $smarty = new Sugar_Smarty();

            $contact_smarty = [];
            $accounts_smarty = [];

            if(isset($_REQUEST['contact_id'])) {
                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    // Данные по Контакту
                    $contact_smarty['ID'] = $seedContact->id;
                    $contact_smarty['NAME'] = $seedContact->full_name;
                    $contact_smarty['EMAIL'] = $seedContact->email1;
                    $contact_smarty['ASSIGNED_USER_NAME'] = $seedContact->assigned_user_name;

                    // Находим Контрагента для Контакта
                    $seedAccount = new Account();
                    $seedAccount->retrieve($seedContact->account_id);

                    if(!empty($seedAccount->id)) {
                        // Если Контрагент для Контакта успешно найден
                        $accounts_smarty[$seedAccount->id] = [
                            'ID' => $seedAccount->id,
                            'NAME' => $seedAccount->name,
                            'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                            'EMAIL1' => $seedAccount->email1,
                            'EMAIL2' => $seedAccount->email2,
                            'SELECTED' => true,
                        ];
                    }

                    // Попытка найти Контрагентов, подходящих для текущего Контакта

                    $domains = [];
                    if(!empty($seedContact->email1)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }
                    if(!empty($seedContact->email2)) {
                        // Домен почты
                        $email_array = explode("@", $seedContact->email1);
                        $domains[] = $email_array[1];
                    }

                    $domains = array_unique($domains);

                    // Контрагенты, у которых есть такой домен
                    foreach ($domains as $domain) {
                        $sql = "SELECT `id` FROM `accounts` WHERE `deleted` = 0 AND `website` LIKE '%{$domain}'";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`
                        FROM
                            `accounts`
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `accounts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Accounts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $seedAccount->email1,
                                    'EMAIL2' => $seedAccount->email2,
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }

                    // Контрагенты, у которых есть Контакты с емайл в заданном домене
                    if($domain != '') {
                        $sql = "
                        SELECT
                            `accounts`.`id`,
                            `email_addresses`.`email_address`
                        FROM
                            `accounts`
                        INNER JOIN
                            `accounts_contacts`
                            ON `accounts_contacts`.`account_id` = `accounts`.`id`
                            AND `accounts_contacts`.`deleted` = 0
                        INNER JOIN
                            `contacts`
                            ON `contacts`.`id` = `accounts_contacts`.`contact_id`
                            AND `contacts`.`deleted` = 0
                        INNER JOIN
                            `email_addr_bean_rel`
                            ON `email_addr_bean_rel`.`bean_id` = `contacts`.`id`
                            AND `email_addr_bean_rel`.`bean_module` = 'Contacts'
                            AND `email_addr_bean_rel`.`deleted` = 0
                        INNER JOIN
                            `email_addresses`
                            ON `email_addresses`.`id` = `email_addr_bean_rel`.`email_address_id`
                            AND `email_addresses`.`deleted` = 0
                            AND `email_addresses`.`email_address_caps` LIKE '%".strtoupper($domain)."'
                        WHERE
                            `accounts`.`deleted` = 0
                        ";
                        $result = $db->query($sql, true);
                        while ($row = $db->fetchByAssoc($result)) {
                            $seedAccount = new Account();
                            $seedAccount->retrieve($row['id']);
                            if(!empty($seedAccount->id) AND !isset($accounts_smarty[$seedAccount->id])) {
                                // Если Контрагент корректно найден
                                $accounts_smarty[$seedAccount->id] = [
                                    'ID' => $seedAccount->id,
                                    'NAME' => $seedAccount->name,
                                    'WEBSITE' => $seedAccount->website != 'http://' ? $seedAccount->website : '',
                                    'EMAIL1' => $row['email_address'],
                                    'SELECTED' => false,
                                ];
                            }
                        }
                    }
                }
            }

            // Поля для редактирования
            $seedCase = new aCase();
            $fields_smarty = getFields($seedCase, 'new');

            // Формат даты
            $dateFormat = $timedate->get_user_date_format();
            $dateFormat = str_replace("yyyy", 'yy', $dateFormat);


            $smarty->assign("SITE_URL", $sugar_config['site_url']);
            $smarty->assign("ACTION", $_REQUEST['action']);
            $smarty->assign("contact", $contact_smarty);
            $smarty->assign("accounts", $accounts_smarty);
            $smarty->assign("fields", $fields_smarty);
            $smarty->assign("CALENDAR_FORMAT", $dateFormat);
            $smarty->assign('CALENDAR_FDOW', $current_user->get_first_day_of_week());
            $smarty->assign('TIME_SEPARATOR', ':');
            $smarty->assign("actionTpl", 'custom/include/chromeMailExtension/tpls/action.' . $_REQUEST['action'] . '.tpl');
            $smarty->assign("RND", $_REQUEST['rnd']);
            $smarty->assign("TOKEN", $_REQUEST['token']);
            $smarty->assign("LANG", $GLOBALS['current_language']);

            $smarty->display("custom/include/chromeMailExtension/tpls/main.tpl");

            break;


        case 'saveCaseForContact':
            // Сохранение нового Обращения для Контакта

            if(isset($_REQUEST['contact_id'])) {
                // Если был передан КОнтакт

                $seedContact = new Contact();
                $seedContact->retrieve($_REQUEST['contact_id']);

                if(!empty($seedContact->id)) {
                    // Если Контакт корректно найден

                    $seedCase = new aCase();
                    $seedCase->name = $_REQUEST['name'];
                    $seedCase->description = $_REQUEST['description'];
                    $seedCase->resolution = $_REQUEST['resolution'];
                    $seedCase->priority = $_REQUEST['priority'];
                    $seedCase->status = $_REQUEST['status'];
                    $seedCase->type = $_REQUEST['type'];
                    $seedCase->assigned_user_id = $_REQUEST['assigned_user_id'];
                    $seedCase->contact_id = $seedContact->id;

                    // Обрабатываем привязку к Контрагенту
                    $seedAccount = new Account();
                    if(isset($_REQUEST['account_select'])) {
                        // Если Контрагента в принципе какого то выбрали
                        if($_REQUEST['account_select'] == 'other') {
                            // Был выбран пункт создания нового Контрагента
                            if(isset($_REQUEST['account_id']) AND $_REQUEST['account_id'] != '') {
                                // Если был найден и выбран Контрагент
                                $seedAccount->retrieve($_REQUEST['account_id']);
                                if(!empty($seedAccount->id)) {
                                    // Если Контрагент корректно найден

                                    if($seedAccount->name != $_REQUEST['account_name']) {
                                        // Был в итоге выбран другой Контрагент
                                        $seedAccount = new Account();
                                        $seedAccount->name = $_REQUEST['account_name'];
                                        $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                        $seedAccount->save();
                                    }
                                }
                            } elseif(isset($_REQUEST['account_name']) AND $_REQUEST['account_name'] != '') {
                                // Было указано название Контрагента
                                $seedAccount->name = $_REQUEST['account_name'];
                                $seedAccount->assigned_user_id = $_REQUEST['assigned_user_id'];
                                $seedAccount->save();
                            }
                        } else {
                            // Выл указан пункт выбора предопределенного значения ранее найденного и предложенного Контрагента
                            $seedAccount->retrieve($_REQUEST['account_select']);
                        }
                    }
                    if(!empty($seedAccount->id)) {
                        $seedCase->account_id = $seedAccount->id;
                    }

                    $seedCase->save();

                    // Отправляем на страницу просмотра Контакта
                    $url = "?entryPoint=chromeMailExtension&rnd=".$_REQUEST['rnd']."&token=".$_REQUEST['token']."&action=showInfoForEmail&email=" . $seedContact->email1;
                    header("Location: " . $url);
                    exit;
                }

            }

            break;



    }

}

/**
 * Получить список полей указанного объекта
 * @param $bean
 * @return array
 */
function getFields($bean, $saveType = 'edit') {
    global $current_language;
    global $app_strings;
    global $app_list_strings;

    $return_array = [];

    $mod_strings= return_module_language($current_language, $bean->module_dir);

    foreach ($GLOBALS[$saveType . 'Fields'][$bean->module_dir] as $key => $fieldName) {

        if(is_array($fieldName)) {
            // Если поле имеет описание
            if(isset($fieldName['function'])) {
                $function = 'getField_' . $fieldName['function'];
                if(function_exists($function)) {
                    // Переданная функция существует

                    // Название поля
                    $label = isset($mod_strings[$bean->field_name_map[$key]['vname']]) ? $mod_strings[$bean->field_name_map[$key]['vname']] : $bean->field_name_map[$key]['vname'];
                    $label = preg_replace("|:$|is", "", $label);

                    // Итоговые данные
                    $return_array[$key] = [
                        'NAME' => $key,
                        'LABEL' => $label,
                        'HTML' => $function(),
                    ];

                }
            }
        } else {
            // Просто название Поля
            $sfh = new SugarFieldHandler();
            $template = $sfh->displaySmarty('fields', $bean->field_name_map[$fieldName], 'EditView', []);

            // Сохраняем шаблон в файл
            $tmp_dir = 'cache/modules/'.$bean->module_dir.'/process/';
            mkdir_recursive($tmp_dir);
            $fileTPL = $tmp_dir . $fieldName . '.tpl';
            $file = fopen($fileTPL, 'w+');
            fwrite($file, $template);
            fclose($file);
            $ss = new Sugar_Smarty();

            $fields_smarty = [
                $fieldName => [
                    'name' => $fieldName,
                    'value' => $bean->$fieldName,
                ],
            ];
            if(in_array($bean->field_name_map[$fieldName]['type'], ['enum','dynamicenum']) AND isset($bean->field_name_map[$fieldName]['options'])) {
                // Добавляем в сценарий список, если требуется
                $fields_smarty[$fieldName]['options'] = $app_list_strings[$bean->field_name_map[$fieldName]['options']];
            }

            $ss->assign("fields", $fields_smarty);
            $ss->assign("APP", $app_strings);
            $ss->assign("CALENDAR_FORMAT", $app_strings);

            // Определение названия поля
            $label = isset($mod_strings[$bean->field_name_map[$fieldName]['vname']]) ? $mod_strings[$bean->field_name_map[$fieldName]['vname']] : $bean->field_name_map[$fieldName]['vname'];
            $label = preg_replace("|:$|is", "", $label);

            $return_array[$fieldName] = [
                'NAME' => $fieldName,
                'LABEL' => $label,
                'HTML' => $ss->fetch($fileTPL),
            ];


            if(isset($bean->field_name_map[$fieldName]['function']) AND isset($bean->field_name_map[$fieldName]['function']['name']) AND isset($bean->field_name_map[$fieldName]['function']['returns']) AND $bean->field_name_map[$fieldName]['function']['returns'] == 'html') {
                // Если содержимое поля должна сгенерить функция

                if(isset($bean->field_name_map[$fieldName]['function']['include']) AND file_exists($bean->field_name_map[$fieldName]['function']['include'])) {
                    // Если указан файл с функцией и он существует
                    include_once $bean->field_name_map[$fieldName]['function']['include'];
                }
                if(function_exists($bean->field_name_map[$fieldName]['function']['name'])) {
                    // Если функция существует
                    $function = $bean->field_name_map[$fieldName]['function']['name'];

                    $return_array[$fieldName]['HTML'] = $function($bean, $fieldName, $bean->$fieldName, 'EditView');
                }
            }


        }



    }

    return $return_array;

}

/**
 * Список пользователей для поля Ответственный
 * @return string
 */
function getField_newObjectAssignedUser() {
    global $db;

    // Список активных пользователей
    $sql = "SELECT `id`, `last_name`, `first_name` FROM `users` WHERE `deleted` = 0 AND `status` = 'Active' AND (`show_on_employees` = 1 OR `is_admin` = 1) AND `employee_status` = 'Active' ORDER BY `first_name`, `last_name` ASC";
    $result = $db->query($sql, true);
    $users_array = ['' => ''];
    while ($row = $db->fetchByAssoc($result)) {
        $users_array[$row['id']] = $row['first_name'] . ' ' . $row['last_name'];
    }

    $return_html = '';

    $return_html .= '<select name="assigned_user_id" id="assigned_user_id">';
    $return_html .= get_select_options_with_id($users_array, $GLOBALS['current_user']->id);
    $return_html .= '</select>';


    return $return_html;
}

/**
 * Список кол-ва часов для длительности
 * @return string
 */
function getField_getDurationHours() {
    global $db;

    $hours_array = [
        '0' => '0',
        '1' => '1',
        '2' => '2',
        '3' => '3',
        '4' => '4',
        '5' => '5',
        '6' => '6',
        '7' => '7',
        '8' => '8',
        '9' => '9',
        '10' => '10',
        '11' => '11',
        '12' => '12',
    ];

    $return_html = '';

    $return_html .= '<select name="duration_hours" id="duration_hours" style="width: 40px;">';
    $return_html .= get_select_options_with_id($hours_array, '0');
    $return_html .= '</select>';


    return $return_html;
}