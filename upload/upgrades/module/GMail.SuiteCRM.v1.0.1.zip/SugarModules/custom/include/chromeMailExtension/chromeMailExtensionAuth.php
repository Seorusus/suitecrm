<?php
$http_origin = $_SERVER['HTTP_ORIGIN'];

if ($http_origin == "https://mail.google.com") {
    header("Access-Control-Allow-Origin: $http_origin");
}


$token = '';

if(isset($_REQUEST['rnd'])) {
    // Если в запросе пришло случайное число

    if(isset($_SESSION['authenticated_user_id']) AND !empty($_SESSION['authenticated_user_id']) AND $_SESSION['authenticated_user_id'] != '') {
        // Есть авторизация текущего пользователя

        // Создаем токен
        $token = md5($_REQUEST['rnd'] . '+' . date("Y-m-d"));

    }

}

// Выдаем токен
echo 'var CRMToken = "'. $token.'";';

/**
$json = new JSON();
echo $json->encode([
    'token' => $token,
    'http_origin' => $http_origin,
]);

**/