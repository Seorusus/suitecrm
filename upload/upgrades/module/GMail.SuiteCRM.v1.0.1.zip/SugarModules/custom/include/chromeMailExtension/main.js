var gmail;
var mainCRM;
var extPath = '/custom/include/chromeMailExtension/';
var currentWindowWidth;
var crmAll;

/**
 * Перезагрузка для попадания в функционал GMail
 * @param f
 */
function refresh(f) {
    if ((/in/.test(document.readyState)) || (typeof Gmail === undefined)) {
        setTimeout('refresh(' + f + ')', 10);
    } else {
        f();
    }
}

var rnd = Math.random();

var main = function () {
    // NOTE: Always use the latest version of gmail.js from
    // https://github.com/KartikTalwar/gmail.js

    console.log('Мы в Gmail!');

    gmail = new Gmail();
    console.log('SuiteCRM: GMail extension initialized for ', gmail.get.user_email())

    // Определяем путь до CRM клиента
    mainCRM = localStorage['crmhosting.gmail.' + gmail.get.user_email() + '.settings-crm-url'];

    // Список всех ранее использованных URl CRM
    if(typeof localStorage['crmhosting.gmail.crm.all'] == 'undefined') {
        // Если переменная с URL еще не определялась
        // Определяем её
        localStorage['crmhosting.gmail.crm.all'] = JSON.stringify([]);
    }
    crmAll = JSON.parse(localStorage['crmhosting.gmail.crm.all']);

    // Отправляем запрос на авторизацию в CRM
    checkCRMAuth();


}

function checkCRMAuth() {

    // Отправляем запрос на получение токена
    console.log('Отправляем запрос на получение токена');
    $.getScript(mainCRM + "/?entryPoint=chromeMailExtensionAuth&rnd=" + rnd, function () {

        console.log('Запрос с токеном пришел');


        // Загружаем панель с данными по письму
        var postData = {
            rnd: rnd,
            token: CRMToken
        };
        console.log('postData:', postData);

        $.post(mainCRM + extPath + 'templates.php', postData).done(function(data){
            //console.log('document ready data');
            $('body').append(data);

            // Отображаем панель в зависимости от контекста
            contextPanelShow();

            // Отображаем кнопку с меню
            AttachMenu();

        });



    });
}

/**
 * Отображение
 */
function contextPanelShow() {

    /************************************************
     * Отображение панели на экране
     */


    // Фиксируем почту для последнего авторизованного захода
    localStorage['crmhosting.gmail.latest.user_email'] = gmail.get.user_email();


    gmail.observe.on('view_thread', function (obj) {
        console.log('view_thread', obj);
    });

    // now we have access to the sub observers view_email and load_email_menu
    gmail.observe.on('view_email', function (obj) {
        console.log('view_email', obj);

        // Получение шаблонов
        var templateShowPanel = Handlebars.compile($("#crmhosting-panel-left-contact").html());
        var templateShowPanelNoAuth = Handlebars.compile($("#crmhosting-panel-left-no-auth").html());

        if(typeof CRMToken != 'undefined' && CRMToken != '') {
            // Токен загрузился

            // Определяем емайл, который открыли
            var email = new gmail.dom.email(obj.$el[0]);

            var dom = email.dom();
            var body = email.body();
            var id = email.id;

            var to = email.to();
            var toList = [];
            var toNameList = [];
            for (toidx in to) {
                toList.push(to[toidx].email.toLowerCase().trim());
                toNameList.push(to[toidx].name);
            }

            var data = {
                site_url: mainCRM,
                rnd: rnd,
                token: CRMToken,
                action: 'showInfoForEmail',
                mailbox: gmail.get.user_email(),
                email: email.from().email.toLowerCase().trim(),
                fromName: encodeURI(email.from().name.trim()),
                to: toList,
                toNames: toNameList
            };

            console.log('templateShowPanel data: ', data);

            $('#CRMHosting_panelDiv').html(templateShowPanel(data));

        } else {
            // Токен не загружен
            console.log('Токен не загружен!');
            var data = {
                site_url: mainCRM,
                action: 'crmNotAuth',
            };
            var html = templateShowPanelNoAuth(data);
            console.log('html = ', html);
            $('#CRMHosting_panelDiv').html(html);

        }

        // Определяем текущие настройки ширины экрана
        currentWindowWidth = $(window).width();
        currentWindowDelta = 0;

        setInterval(function(){
            // Задаем высоту фрейма с содержимым
            var windowHeight = $(window).height();
            var windowWidth = $(window).width();
            var iframeHeight = $('#crmhosting-panel-left-contact-div').height();
            var iframeLeft = $('#crmhosting-panel-left-contact-div').css('left');
            var topHeightPercent = 20;
            var topHeight = windowHeight * topHeightPercent / 100;
            $('#crmhosting-panel-left-contact-div').css('top', topHeight);
            //$('#crmhosting-panel-left-contact-div').css('float', 'left');
            //$('#crmhosting-panel-left-contact-div').css('right', '-255px');
            $('#crmhosting-panel-left-contact-div-content').css('height', windowHeight - topHeight);

            if(windowWidth != currentWindowWidth) {
                // Ширина экрана поменялась
                // Сдвигаем панель


                var deltaWidth = windowWidth - currentWindowWidth;
                console.log('windowWidth = ', windowWidth);
                console.log('currentWindowWidth = ', currentWindowWidth);
                console.log('deltaWidth = ', deltaWidth);
                if(deltaWidth > 0) {
                    deltaWidth = '+=' + deltaWidth;
                } else {
                    deltaWidth = '-=' + Math.abs(deltaWidth);
                }
                console.log('deltaWidth = ', deltaWidth);
                $('#crmhosting-panel-left-contact-div').animate({
                    left: deltaWidth,
                }, 200, function() {
                    currentWindowWidth = windowWidth;
                });

            }

        },500);

        // Анимация движения панели
        var $panel = $('#crmhosting-panel-left-contact-div');
        if ($panel.length) {
            var $sticker = $panel.children('#crmhosting-panel-left-contact-div-sticker');
            var showPanel = function() {
                $panel.animate({
                    left: '-=355',
                }, 200, function() {
                    $(this).addClass('visible');
                });
            };
            var hidePanel = function() {
                $panel.animate({
                    left: '+=355',
                }, 200, function() {
                    $(this).removeClass('visible');
                });
            };
            $sticker
                .click(function() {
                    if ($panel.hasClass('visible')) {
                        hidePanel();
                    }
                    else {
                        showPanel();
                    }
                }).mouseenter(function() {
                if (!$panel.hasClass('visible')) {
                    showPanel();
                }
            }).andSelf()
                .children('.close').click(function() {
                $panel.remove();
            });
        }
    });

}

/**
 * Добавляем кнопку с меню
 * @constructor
 */
function AttachMenu() {
    // Шаблон Кнопки
    var templateTopMenu = Handlebars.compile($("#crmhosting-panel-menu").html());

    // Данные для шаблона Кнопки
    var data = {
        mainCRM: mainCRM,
        extPath: extPath
    };
    //console.log('templateTopMenu: ', templateTopMenu(data));
    // Добавляем меню
    gmail.tools.add_toolbar_button(templateTopMenu(data), function(){
        // Нажатие на меню приводит к раскрытию списка
        var submenu = $('nav.options-menu');
        if ( $(submenu).is(':hidden') ) {
            $(submenu).slideDown(-200);
        } else {
            $(submenu).slideUp(-200);
        }

    });

    // Шаблон Настроек
    var templateTopMenuSettings = Handlebars.compile($("#crmhosting-settings-template").html());

    // Прикрепляем шаблон к странице
    var data = {
        urls: crmAll
    };
    console.log('data templateTopMenuSettings: ', data);
    $('body').append(templateTopMenuSettings(data));

    // Закрепляем окно как диалоговое
    /**
     **/
    // Настраиваем обработку выбора меню с Настройками
    $('#mailExtTemplateTopMenuNav li.settings').click(function(){
        showSettingsPanel();
    });



}

/**
 * Функция отображения диалога с настройками
 */
function showSettingsPanel() {

    console.log('showSettingsPanel - start');

    // Устанавливаем значения в поля
    // Основные настройки: URL SuiteCRM
    $('#crmhosting-settings-crm-url').val(localStorage['crmhosting.gmail.' + gmail.get.user_email() + '.settings-crm-url']);


    // Инициируем диалоговое окно
    $("#crmhosting-settings-div").dialog({
        resizable: false,
        autoOpen: false,
        width: 800,
        modal: false,
        buttons: {
            "Save": function () {
                // Срабатывание формы

                // Основные настройки: URL SuiteCRM
                var url = $('#crmhosting-settings-crm-url').val();
                if(!url) {
                    url = '';
                } else {
                    var lastChar = url.substr(-1);
                    if (lastChar != '/') {
                        url = url + '/';
                    }
                }

                localStorage['crmhosting.gmail.' + gmail.get.user_email() + '.settings-crm-url'] = url;

                // Добавляем URL в список когда-либо использованных URL
                if(!in_array(url, crmAll)) {
                    // Если URL еще пока нет в списке
                    // Добавляем
                    crmAll.push(url);
                    localStorage['crmhosting.gmail.crm.all'] = JSON.stringify(crmAll);;
                }
                

                // Фиксируем почту для последнего авторизованного захода
                localStorage['crmhosting.gmail.latest.user_email'] = gmail.get.user_email();

                // Скрываем форму
                $(this).dialog("close");

                // Перезагружаем страницу
                location.reload();

            },
            "Cancel": function () {
                $(this).dialog("close");
            }
        }
    });

    // Инициируем вкладки в диалоговом окне
    $( "#crmhosting-settings-tabs" ).tabs();

    // Отображаем окно
    $('#crmhosting-settings-div').dialog('open');

    //$('#crmhosting-settings-div').show();

    console.log('showSettingsPanel - stop');
}

/**
 * Функция определения вхождения значения в массив
 * @param needle
 * @param haystack
 * @returns {boolean}
 */
function in_array(needle, haystack) {
    for(var i in haystack) {
        if(haystack[i] == needle) return true;
    }
    return false;
}

/**
 * Функция поиска ключа для заданного значения в массиве
 * @param needle
 * @param haystack
 * @returns {*}
 */
function array_search(needle, haystack) {
    for(var i in haystack) {
        if(haystack[i] == needle) return i;
    }
    return false;
}


// Стартуем ожидание
refresh(main);