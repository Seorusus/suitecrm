<?php
$http_origin = $_SERVER['HTTP_ORIGIN'];
header("Access-Control-Allow-Origin: *");
$site_url = 'https://gmail.crmhosting.ru';
?>

<link href="<?=$site_url;?>/custom/include/chromeMailExtension/stylePanelSticker.css" rel="stylesheet" type="text/css">

<div id="CRMHosting_panelDiv"></div>

<script id="crmhosting-panel-left-contact" type="text/x-handlebars-template">
    <div id="crmhosting-panel-left-contact-div" class="cs-gmail-sidebar-content">
        <div id="crmhosting-panel-left-contact-div-sticker"></div>
        <div id="crmhosting-panel-left-contact-div-content">
            <iframe src="{{site_url}}/?entryPoint=chromeMailExtension&rnd={{rnd}}&token={{token}}&action={{action}}&email={{email}}&fromName={{fromName}}" style="width:100%;height: 100%;padding: 0px;border: 0px;"></iframe>
        </div>
    </div>
</script>

<script id="crmhosting-panel-left-no-auth" type="text/x-handlebars-template">
    <div id="crmhosting-panel-left-contact-div" class="cs-gmail-sidebar-content">
        <div id="crmhosting-panel-left-contact-div-sticker"></div>
        <div id="crmhosting-panel-left-contact-div-content"><iframe src="{{site_url}}/?entryPoint=chromeMailExtension&action={{action}}" style="width:100%;height: 100%;padding: 0px;border: 0px;"></iframe></div>
    </div>
</script>

<script id="mailExtLeftPanel_showEmail" type="text/x-handlebars-template">
    <section class="middle">
        <section class="entry-details all-sections" style="position: static">

            <section>
                <div id="st-info" class="section-title" style="background-color: #49c76a">Info</div>
                <div class="section-content contact-info Contacts" data-id="{{contact_id}}" data-name="{{contact_name}}">
                    <div style="float:left; width:55px; height:55px;">
                        <img class="avatar" src="{{site_url}}/include/ext/chromeMailExtension/avatar1.jpg" width="55px">
                    </div>
                    <div class="name-attr" style="float:left; width:150px; margin-left:5px;">
                        <a href="{{site_url}}/index.php?action=DetailView&amp;module=Contacts&amp;record={{contact_id}}" class="e name" target="_blank">{{contact_name}}</a>
                        <br><span class="title-and-company"><span class="account_name"><a href="{{site_url}}/index.php?action=DetailView&amp;module=Accounts&amp;record={{account_id}}" class="e name" target="_blank">{{account_name}}</a></span></span>
                        <br><small>Assigned to {{contact_assigned_user_name}}</small>
                    </div>

                    <br style="clear:both;">
                    <div class="sidebar-item"><strong class="key">Email:</strong> <a href="javascript:void(0)" class="value email">{{contact_email}}</a></div>
                    <br style="clear:both;">
                    <br style="clear:both;">
                    <div>
                        <div>Contact type:</div>
                        <div>{{contact_fields_contact_type_input}}</div>
                    </div>
                </div>
            </section>

        </section>
    </section>
</script>

<script id="crmhosting-panel-menu" type="text/x-handlebars-template">
    <link href="{{mainCRM}}{{extPath}}gdropdown.css" rel="stylesheet" type="text/css">
    <div class="T-I-J3 J-J5-Ji" style='width: 106px; height: 20px; opacity: 1; background: no-repeat url({{mainCRM}}{{extPath}}img/suitecrm_logo_small_top_menu.png)' ></div>
    <nav id="mailExtTemplateTopMenuNav" class="options-menu" style="display: none; position: absolute;top: 29px;left: 0px;width: 150px;background-color: white;border: 1px solid grey;border-radius: 2px;">
        <ol class="menu-options" style="text-align: left;">
            <li class="menu-options-item">
                <a href="https://crmhosting.ru/" class="menu-options-label-name" style="text-decoration: none;" target="_blank">CRMHosting.ru</a>
            </li>
            <li class="menu-options-item">
                <a href="https://spravkacrm.ru/" class="menu-options-label-name" style="text-decoration: none;" target="_blank">SpravkaCRM.ru</a>
            </li>
            <li class="menu-options-item">
                <a href="https://suitecrm.com/" class="menu-options-label-name" style="text-decoration: none;" target="_blank">SuiteCRM.com</a>
            </li>
            <li class="menu-options-item">
                <a href="{{mainCRM}}" class="menu-options-label-name" style="text-decoration: none;" target="_blank">База</a>
            </li>
            <li class="menu-options-item settings">
                <label class="menu-options-label-name">Настройки</label>
            </li>
        </ol>
    </nav>
</script>

<script id="crmhosting-settings-template" type="text/x-handlebars-template">
    <div id='crmhosting-settings-div' title='SuiteCRM: Настройки' style="display: none;">

        <div id="crmhosting-settings-tabs">
            <ul>
                <li>
                    <a href="#general">Основные настройки</a>
                </li>
            </ul>
            <div id="general">
                <table>
                    <tr>
                        <td style="text-align: right;"><label for="crmhosting-settings-crm-url">URL CRM-системы:</label></td>
                        <td>
                            <input type="text" name="crmhosting-settings-crm-url" id="crmhosting-settings-crm-url" list="crmhosting-settings-crm-url-datalist" size="80" placeholder="https://">
                            <datalist id="crmhosting-settings-crm-url-datalist">
                                {{#each urls}}
                                <option value="{{this}}"></option>
                                {{/each}}
                            </datalist>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

    </div>
</script>
