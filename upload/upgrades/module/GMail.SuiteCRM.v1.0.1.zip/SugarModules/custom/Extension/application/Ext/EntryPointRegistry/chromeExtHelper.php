<?php 
	$entry_point_registry['chromeMailExtensionAuth'] = array(
	    'file' => 'custom/include/chromeMailExtension/chromeMailExtensionAuth.php',
	    'auth' => false
	);
	$entry_point_registry['chromeMailExtension'] = array(
	    'file' => 'custom/include/chromeMailExtension/chromeMailExtension.php',
	    'auth' => false
	);