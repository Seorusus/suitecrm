<?php
// created: 2020-07-31 12:25:15
$dictionary["incom_incoming_marketing"]["fields"]["incom_incoming_marketing_leads"] = array (
  'name' => 'incom_incoming_marketing_leads',
  'type' => 'link',
  'relationship' => 'incom_incoming_marketing_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'side' => 'right',
  'vname' => 'LBL_INCOM_INCOMING_MARKETING_LEADS_FROM_LEADS_TITLE',
);
