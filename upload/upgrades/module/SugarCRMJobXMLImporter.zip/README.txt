JobXMLImporter 1.0.0
Antonio Musarra

Elevator statement
New and special in this release
Hardware and software requirements
Installation instructions, getting started tips, and documentation
Important known problems
Version history

Contact us at:
Antonio Musarra
http://www.dontesta.it/blog
antonio.musarra@gmail.com
January 29, 2014 - Copyright (C) <2009-2014>