<?php
 /*
   Created By : Urdhva Tech Pvt. Ltd.
   Created date : 07/19/2013
   Contact at : contact@urdhva-tech.com
   Skype : urdhvatech
   Module : stickyNote 1.0
*/

$app_list_strings['moduleList']['StickyNote'] = 'Стикеры';
