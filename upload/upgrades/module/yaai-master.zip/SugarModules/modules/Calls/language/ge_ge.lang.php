<?php
// created: 2009-06-18 17:38:48
$mod_strings = array (
  'VALUE' => 'CallerId',
  'LBL_ASTERISK_CALLER_ID' => 'Telefonnummer',
);
?>
