php configuratorGeneratorUtil.php > asterisk_configurator_table.tpl

cat asterisk_configurator_table.tpl

echo ""
echo "^---- Inspect above, if you don't have a needed modstring defined it'll be listed at end of file"