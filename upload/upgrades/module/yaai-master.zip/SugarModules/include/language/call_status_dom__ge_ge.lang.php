<?php

$app_list_strings['call_status_dom']=array (
  'Planned' => 'Geplant',
  'Held' => 'Gehalten',
  'Not Held' => 'Nicht Gehalten',
  'Missed' => 'Verpasst',
  'In Limbo' => 'In Limbo',
);