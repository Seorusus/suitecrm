##Callinize for SugarCRM
Callinize (formerly known as yaai) is the premier telephony integration supporting Asterisk and SugarCRM.

This repo is for the community edition of Callinize.  Be sure to checkout [Callinize Basic & Pro Features here](http://www.callinize.com)

Documentation for this project is on the Wiki pages.
If you have questions, please post them in the issues section.

### Demo Video
http://www.youtube.com/watch?v=UAdxUNlPDzQ

### Links to Documentation
https://github.com/blak3r/yaai/wiki/User-Manual
See also: https://github.com/blak3r/yaai/wiki/_pages

### Callinize Discussion Forum for asking questions, reporting bugs, feature requests, etc.
https://github.com/blak3r/yaai/issues

For paid support or custom development requests, please contact us at hello@callinize.com.

### Social
Subscribe to the mailing list here for news: http://eepurl.com/rmdML

Follow us on twitter @callinize


[![gitimg](https://gitimg.com/blak3r/yaai/README.md/track)](http://gitimg.com)
