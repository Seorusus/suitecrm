<?php
if (!defined('sugarEntry')) define('sugarEntry', true);
/**
 * Created by PhpStorm.
 * User: CRMHosting.ru
 * Date: 14.07.16
 * Time: 12:15
 */

function post_install() {

    // Пересоздаем кеш
    require_once('modules/Administration/QuickRepairAndRebuild.php');

    $randc = new RepairAndClear();
    $randc->repairAndClearAll(array('clearAll'), array(translate('LBL_ALL_MODULES')), false, true);

}



