<?php
define('sugarEntry', TRUE);
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
require_once('include/entryPoint.php');
require_once('modules/Configurator/Configurator.php');

$sel_mod = $_REQUEST['selModuleDrop'];

$disp_mod_listfields = $_REQUEST['disp_list_fields'];


array_splice($sel_mod, 0, 1);

array_splice($disp_mod_listfields, 0, 1);



$cfg = new Configurator();
if($disp_mod_listfields!=''&&$sel_mod!='')
 {
 	
 	$cfg->config['fynmobile_listview_fields'][$sel_mod] = implode(",",$disp_mod_listfields);
   
 }
 
 
 $cfg->saveConfig();

?>