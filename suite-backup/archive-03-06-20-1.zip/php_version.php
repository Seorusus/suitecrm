<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

// The absolute minimum version on which to install SuiteCRM
define('SUITECRM_PHP_MIN_VERSION', '5.6.0');

// The minimum recommended version on which to install SuiteCRM
define('SUITECRM_PHP_REC_VERSION', '7.1.0');
