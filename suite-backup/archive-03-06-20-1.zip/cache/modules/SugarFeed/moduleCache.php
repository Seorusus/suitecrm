<?php

$feedModules = array (
  'UserFeed' => 'UserFeed',
  'Leads' => 'Leads',
  'Contacts' => 'Contacts',
  'Cases' => 'Cases',
  'Opportunities' => 'Opportunities',
);