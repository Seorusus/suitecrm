<?php

$linkTypeList = array (
  'Link' => 'Link',
  'YouTube' => 'YouTube',
  'Image' => 'Image',
);