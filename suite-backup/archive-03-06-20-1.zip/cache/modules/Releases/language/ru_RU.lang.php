<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Версии',
  'LBL_MODULE_TITLE' => 'Версии - ГЛАВНАЯ',
  'LBL_SEARCH_FORM_TITLE' => 'Поиск версий',
  'LBL_LIST_FORM_TITLE' => 'Список версий',
  'LBL_NEW_FORM_TITLE' => 'Новая версия',
  'LBL_RELEASE' => 'Версия:',
  'LBL_LIST_NAME' => 'Версия',
  'LBL_NAME' => 'Версия:',
  'LBL_LIST_LIST_ORDER' => 'Порядок',
  'LBL_LIST_ORDER' => 'Порядок:',
  'LBL_LIST_STATUS' => 'Статус',
  'LBL_STATUS' => 'Статус:',
  'LNK_NEW_RELEASE' => 'Список версий',
  'NTC_DELETE_CONFIRMATION' => 'Вы уверены, что хотите удалить эту запись?',
  'ERR_DELETE_RECORD' => 'Вы должны указать запись для удаления версии.',
  'NTC_STATUS' => 'Установите статус на "Не активна" для удаления этой версии из списка',
  'NTC_LIST_ORDER' => 'Установить порядок следования версий',
  'release_status_dom' => 
  array (
    'Active' => 'Активна',
    'Inactive' => 'Не активна',
  ),
  'LBL_EDITLAYOUT' => 'Изменить макет',
);