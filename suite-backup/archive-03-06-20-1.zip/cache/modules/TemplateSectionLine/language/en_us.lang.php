<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'LBL_DESCRIPTION' => 'Description',
  'LBL_NAME' => 'Name',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_GRP' => 'Group',
  'LBL_ORD' => 'Order',
  'LBL_THUMBNAIL' => 'Thumbnail',
);