<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'LBL_EMAIL_ADDRESS_ID' => 'ID',
  'LBL_EMAIL_ADDRESS' => 'Адрес E-mail',
  'LBL_EMAIL_ADDRESS_CAPS' => 'Адрес E-mail (заглавными буквами)',
  'LBL_INVALID_EMAIL' => 'Неверный E-mail',
  'LBL_OPT_OUT' => 'Не писать',
  'LBL_CONFIRM_OPT_IN' => 'Подтверждать выбор',
  'LBL_DATE_CREATE' => 'Дата создания',
  'LBL_DATE_MODIFIED' => 'Дата изменения',
  'LBL_DELETED' => 'Удалить',
);