<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'action' => 'Action',
  'date_modified' => 'Date of Last Action',
  'item_id' => 'ID',
  'item_summary' => 'Name',
  'module_name' => 'Module Name',
  'users' => 'Users',
  'LBL_MODULE_NAME' => 'Trackers',
);