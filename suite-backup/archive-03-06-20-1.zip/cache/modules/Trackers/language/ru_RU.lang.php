<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'action' => 'Действие',
  'date_modified' => 'Дата последнего действия',
  'item_id' => 'ID',
  'item_summary' => 'Название',
  'module_name' => 'Название модуля',
  'users' => 'Пользователи',
  'LBL_MODULE_NAME' => 'Трекеры',
);