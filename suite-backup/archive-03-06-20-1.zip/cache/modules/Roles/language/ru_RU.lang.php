<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'LBL_ROLE' => 'Роль: ',
  'LBL_LANGUAGE' => 'Язык: ',
  'LBL_MODULE_NAME' => 'Роли',
  'LBL_MODULE_TITLE' => 'Роли - ГЛАВНАЯ',
  'LBL_SEARCH_FORM_TITLE' => 'Поиск роли',
  'LBL_LIST_FORM_TITLE' => 'Список ролей',
  'LNK_NEW_ROLE' => 'Создать роль',
  'LNK_ROLES' => 'Роли',
  'LBL_NAME' => 'Имя: ',
  'LBL_DESCRIPTION' => 'Описание: ',
  'LBL_ALLOWED_MODULES' => 'Разрешённые модули: ',
  'LBL_DISALLOWED_MODULES' => 'Неразрешённые модули: ',
  'LBL_ASSIGN_MODULES' => 'Править модули: ',
  'LBL_DEFAULT_SUBPANEL_TITLE' => 'Роли',
  'LBL_USERS' => 'Пользователи',
  'LBL_USERS_SUBPANEL_TITLE' => 'Пользователи',
  'LBL_MODULES' => 'Модули',
);