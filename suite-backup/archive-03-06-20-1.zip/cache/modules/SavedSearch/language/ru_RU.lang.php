<?php
// created: 2020-05-25 15:26:16
$mod_strings = array (
  'LBL_MODULE_TITLE' => 'Мои сохранённые фильтры',
  'LBL_SEARCH_FORM_TITLE' => 'Мои сохранённые фильтры : Фильтр',
  'LBL_LIST_FORM_TITLE' => 'Список фильтров',
  'LBL_DELETE_CONFIRM' => 'Вы действительно хотите удалить выбранный фильтр?',
  'LBL_DELETE_BUTTON_TITLE' => 'Удалить эти условия фильтрации',
  'LBL_SAVE_BUTTON_TITLE' => 'Сохранить текущий фильтр',
  'LBL_LIST_NAME' => 'Имя',
  'LBL_LIST_MODULE' => 'Модуль',
  'LBL_ORDER_BY_COLUMNS' => 'Сортировать по колонке:',
  'LBL_DIRECTION' => 'Сортировка:',
  'LBL_SAVE_SEARCH_AS' => 'Сохранить фильтр как:',
  'LBL_ASCENDING' => 'Восходящая',
  'LBL_DESCENDING' => 'Нисходящая',
  'LBL_MODIFY_CURRENT_FILTER' => 'Выбранный фильтр',
  'LBL_CREATED_BY' => 'Кем создано',
);