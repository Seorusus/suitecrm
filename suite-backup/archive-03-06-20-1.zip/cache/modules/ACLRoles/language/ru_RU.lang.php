<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'LBL_MODULE_NAME' => 'Роли',
  'LBL_MODULE_TITLE' => 'Роли - Главная',
  'LBL_ROLE' => 'Роль',
  'LBL_NAME' => 'Проектная задача',
  'LBL_DESCRIPTION' => 'Описание',
  'LIST_ROLES' => 'Роли',
  'LBL_USERS_SUBPANEL_TITLE' => 'Пользователи',
  'LIST_ROLES_BY_USER' => 'Список ролей по пользователям',
  'LBL_LIST_FORM_TITLE' => 'Роли',
  'LBL_ROLES_SUBPANEL_TITLE' => 'Роли пользователя',
  'LBL_SEARCH_FORM_TITLE' => 'Найти',
  'LBL_CREATE_ROLE' => 'Создать роль',
  'LBL_EDIT_VIEW_DIRECTIONS' => 'Нажмите на элементе для изменения значения.',
  'LBL_ACCESS_DEFAULT' => 'По умолчанию',
  'LBL_ACTION_ADMIN' => 'Тип доступа',
  'LBL_ALL' => 'Все',
  'LBL_DUPLICATE_OF' => 'Дублирует ',
  'LBL_SECURITYGROUPS' => 'Группы пользователей',
);