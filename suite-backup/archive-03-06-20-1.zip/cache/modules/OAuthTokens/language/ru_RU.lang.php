<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'LBL_OAUTH_REQUEST' => 'Токен запроса',
  'LBL_OAUTH_AUTHORIZE' => 'Авторизовать токен',
  'LBL_OAUTH_CONSUMERREQ' => 'Авторизовать токен пользователя <b>%s</b>?',
  'LBL_ASSIGNED_TO_NAME' => 'Пользователь',
  'LBL_ID' => 'ID',
  'LBL_STATUS' => 'Статус',
  'LBL_TS' => 'Отметка времени',
  'LBL_LIST_DELETE' => 'Удалён токен',
  'LBL_CONSUMER' => 'Пользователь',
  'LBL_OAUTH_DISABLED' => 'Поддержка OAuth отключена. Вероятно, отсутствует соответствующее расширение PHP. Для решения вопроса свяжитесь с системным администратором.',
  'LBL_TOKEN_TS' => 'Токен TS',
  'LBL_CALLBACK_URL' => 'Callback URL',
  'LBL_SECRET' => 'Пароль',
  'LBL_TSTATE' => 'Состояние токена',
  'LBL_VERIFY' => 'Проверить',
);