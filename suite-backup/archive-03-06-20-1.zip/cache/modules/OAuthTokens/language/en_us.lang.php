<?php
// created: 2020-05-27 13:09:22
$mod_strings = array (
  'LBL_OAUTH_REQUEST' => 'Request Token',
  'LBL_OAUTH_AUTHORIZE' => 'Authorize Token',
  'LBL_OAUTH_CONSUMERREQ' => 'Authorize token from consumer <b>%s</b>?',
  'LBL_ASSIGNED_TO_NAME' => 'User',
  'LBL_ID' => 'ID',
  'LBL_STATUS' => 'Status',
  'LBL_TS' => 'Timestamp',
  'LBL_LIST_DELETE' => 'Delete Token',
  'LBL_CONSUMER' => 'Consumer Name',
  'LBL_OAUTH_DISABLED' => 'OAuth support not enabled. PHP oauth extension may be missing. Please contact your administrator.',
  'LBL_TOKEN_TS' => 'Token TS',
  'LBL_CALLBACK_URL' => 'Callback URL',
  'LBL_SECRET' => 'Secret',
  'LBL_TSTATE' => 'TState',
  'LBL_VERIFY' => 'Verify',
);