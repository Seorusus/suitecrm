<?php /* Smarty version 2.6.31, created on 2020-05-27 21:00:13
         compiled from include/Dashlets/DashletFooter.tpl */ ?>
</div><div class="mr"></div></div><div class="ft"><div class="bl"></div><div class="ft-center"></div><div class="br"></div></div>