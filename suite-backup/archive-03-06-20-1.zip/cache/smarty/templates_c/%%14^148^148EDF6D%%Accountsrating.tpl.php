<?php /* Smarty version 2.6.31, created on 2020-06-03 01:40:16
         compiled from cache/modules/Import/Accountsrating.tpl */ ?>

<?php if (strlen ( $this->_tpl_vars['fields']['rating']['value'] ) <= 0): ?>
<?php $this->assign('value', $this->_tpl_vars['fields']['rating']['default_value']); ?>
<?php else: ?>
<?php $this->assign('value', $this->_tpl_vars['fields']['rating']['value']); ?>
<?php endif; ?>  
<input type='text' name='<?php echo $this->_tpl_vars['fields']['rating']['name']; ?>
' 
    id='<?php echo $this->_tpl_vars['fields']['rating']['name']; ?>
' size='30' 
    maxlength='100' 
    value='<?php echo $this->_tpl_vars['value']; ?>
' title=''  tabindex='1'      >