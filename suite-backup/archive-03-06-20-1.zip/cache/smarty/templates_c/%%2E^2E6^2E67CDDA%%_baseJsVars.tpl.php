<?php /* Smarty version 2.6.31, created on 2020-06-03 12:54:48
         compiled from modules/Emails/templates/_baseJsVars.tpl */ ?>

<script type="text/javascript" language="Javascript">
var req;
var target;
var flexContentOld = "";
var forcePreview = false;
var inCompose = false;

/* globals for Callback functions */
var email; // AjaxObject.showEmailPreview
var ieId;
var ieName;
var focusFolder;
var meta; // AjaxObject.showEmailPreview
var sendType;
var targetDiv;
var urlBase = 'index.php';
var urlStandard = 'sugar_body_only=true&to_pdf=true&module=Emails&action=EmailUIAjax';

var lazyLoadFolder = null;
</script>