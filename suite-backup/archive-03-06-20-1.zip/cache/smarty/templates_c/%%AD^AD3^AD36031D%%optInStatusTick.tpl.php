<?php /* Smarty version 2.6.31, created on 2020-05-27 21:01:38
         compiled from include/SugarEmailAddress/templates/optInStatusTick.tpl */ ?>
<span class="email-opt-in-container"><span class="email-opt-in <?php echo $this->_tpl_vars['optInFlagClass']; ?>
" title="<?php echo $this->_tpl_vars['optInFlagTitle']; ?>
"><?php echo $this->_tpl_vars['optInFlagText']; ?>
</span></span>