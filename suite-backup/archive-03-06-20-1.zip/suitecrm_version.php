<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version = '7.11.13';
$suitecrm_timestamp = '2020-03-24 17:00:00';
