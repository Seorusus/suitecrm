<?php
// created: 2020-10-15 00:18:14
$dictionary["Campaign"]["fields"]["custo_company_campaigns"] = array (
  'name' => 'custo_company_campaigns',
  'type' => 'link',
  'relationship' => 'custo_company_campaigns',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => 'custo_company',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_COMPANY_CAMPAIGNS_FROM_CUSTO_COMPANY_TITLE',
);
