<?php
// created: 2020-10-15 00:18:13
$dictionary["custo_user"]["fields"]["custo_user_custo_contact_1"] = array (
  'name' => 'custo_user_custo_contact_1',
  'type' => 'link',
  'relationship' => 'custo_user_custo_contact_1',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'vname' => 'LBL_CUSTO_USER_CUSTO_CONTACT_1_FROM_CUSTO_CONTACT_TITLE',
);
