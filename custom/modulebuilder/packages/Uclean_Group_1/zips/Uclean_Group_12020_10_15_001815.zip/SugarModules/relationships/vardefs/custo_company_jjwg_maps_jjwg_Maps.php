<?php
// created: 2020-10-15 00:18:14
$dictionary["jjwg_Maps"]["fields"]["custo_company_jjwg_maps"] = array (
  'name' => 'custo_company_jjwg_maps',
  'type' => 'link',
  'relationship' => 'custo_company_jjwg_maps',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => 'custo_company',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_COMPANY_JJWG_MAPS_FROM_CUSTO_COMPANY_TITLE',
);
