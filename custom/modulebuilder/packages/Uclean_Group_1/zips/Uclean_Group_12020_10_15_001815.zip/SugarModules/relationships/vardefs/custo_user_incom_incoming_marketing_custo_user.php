<?php
// created: 2020-10-15 00:18:13
$dictionary["custo_user"]["fields"]["custo_user_incom_incoming_marketing"] = array (
  'name' => 'custo_user_incom_incoming_marketing',
  'type' => 'link',
  'relationship' => 'custo_user_incom_incoming_marketing',
  'source' => 'non-db',
  'module' => 'incom_incoming_marketing',
  'bean_name' => 'incom_incoming_marketing',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_USER_INCOM_INCOMING_MARKETING_FROM_INCOM_INCOMING_MARKETING_TITLE',
);
