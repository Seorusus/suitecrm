<?php
// created: 2020-10-15 00:18:13
$dictionary["custo_user"]["fields"]["custo_user_custo_contact"] = array (
  'name' => 'custo_user_custo_contact',
  'type' => 'link',
  'relationship' => 'custo_user_custo_contact',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_USER_CUSTO_CONTACT_FROM_CUSTO_CONTACT_TITLE',
);
