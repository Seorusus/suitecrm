<?php
// created: 2020-10-15 00:18:14
$dictionary["custo_company"]["fields"]["custo_company_securitygroups"] = array (
  'name' => 'custo_company_securitygroups',
  'type' => 'link',
  'relationship' => 'custo_company_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_CUSTO_COMPANY_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
