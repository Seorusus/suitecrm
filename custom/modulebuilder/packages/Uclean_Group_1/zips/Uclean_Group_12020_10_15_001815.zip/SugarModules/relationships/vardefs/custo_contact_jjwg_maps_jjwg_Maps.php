<?php
// created: 2020-10-15 00:18:13
$dictionary["jjwg_Maps"]["fields"]["custo_contact_jjwg_maps"] = array (
  'name' => 'custo_contact_jjwg_maps',
  'type' => 'link',
  'relationship' => 'custo_contact_jjwg_maps',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_CONTACT_JJWG_MAPS_FROM_CUSTO_CONTACT_TITLE',
);
