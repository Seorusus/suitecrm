<?php
// created: 2020-10-15 00:18:13
$dictionary["Email"]["fields"]["custo_contact_emails"] = array (
  'name' => 'custo_contact_emails',
  'type' => 'link',
  'relationship' => 'custo_contact_emails',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'vname' => 'LBL_CUSTO_CONTACT_EMAILS_FROM_CUSTO_CONTACT_TITLE',
);
