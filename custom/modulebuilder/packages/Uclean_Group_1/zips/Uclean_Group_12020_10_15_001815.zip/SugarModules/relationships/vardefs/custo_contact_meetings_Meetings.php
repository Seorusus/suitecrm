<?php
// created: 2020-10-15 00:18:13
$dictionary["Meeting"]["fields"]["custo_contact_meetings"] = array (
  'name' => 'custo_contact_meetings',
  'type' => 'link',
  'relationship' => 'custo_contact_meetings',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'vname' => 'LBL_CUSTO_CONTACT_MEETINGS_FROM_CUSTO_CONTACT_TITLE',
);
