<?php
// created: 2020-10-15 00:18:13
$dictionary["Campaign"]["fields"]["custo_contact_campaigns"] = array (
  'name' => 'custo_contact_campaigns',
  'type' => 'link',
  'relationship' => 'custo_contact_campaigns',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_CONTACT_CAMPAIGNS_FROM_CUSTO_CONTACT_TITLE',
);
