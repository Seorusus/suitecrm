<?php
// created: 2020-10-15 00:18:14
$dictionary["ProspectList"]["fields"]["custo_company_prospectlists"] = array (
  'name' => 'custo_company_prospectlists',
  'type' => 'link',
  'relationship' => 'custo_company_prospectlists',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => 'custo_company',
  'vname' => 'LBL_CUSTO_COMPANY_PROSPECTLISTS_FROM_CUSTO_COMPANY_TITLE',
);
