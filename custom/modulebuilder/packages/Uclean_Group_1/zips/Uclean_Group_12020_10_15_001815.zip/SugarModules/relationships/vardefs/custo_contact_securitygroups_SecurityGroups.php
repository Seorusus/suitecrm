<?php
// created: 2020-10-15 00:18:13
$dictionary["SecurityGroup"]["fields"]["custo_contact_securitygroups"] = array (
  'name' => 'custo_contact_securitygroups',
  'type' => 'link',
  'relationship' => 'custo_contact_securitygroups',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => 'custo_contact',
  'vname' => 'LBL_CUSTO_CONTACT_SECURITYGROUPS_FROM_CUSTO_CONTACT_TITLE',
);
