<?php
// created: 2020-10-15 00:18:13
$dictionary["custo_user"]["fields"]["custo_user_emails_1"] = array (
  'name' => 'custo_user_emails_1',
  'type' => 'link',
  'relationship' => 'custo_user_emails_1',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_USER_EMAILS_1_FROM_EMAILS_TITLE',
);
