<?php
// created: 2020-10-15 00:18:13
$dictionary["custo_user"]["fields"]["custo_user_meetings"] = array (
  'name' => 'custo_user_meetings',
  'type' => 'link',
  'relationship' => 'custo_user_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'vname' => 'LBL_CUSTO_USER_MEETINGS_FROM_MEETINGS_TITLE',
);
