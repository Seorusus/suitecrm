<?php
// created: 2020-10-15 00:18:13
$dictionary["custo_user"]["fields"]["custo_user_custo_user"] = array (
  'name' => 'custo_user_custo_user',
  'type' => 'link',
  'relationship' => 'custo_user_custo_user',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => 'custo_user',
  'vname' => 'LBL_CUSTO_USER_CUSTO_USER_FROM_CUSTO_USER_L_TITLE',
);
$dictionary["custo_user"]["fields"]["custo_user_custo_user"] = array (
  'name' => 'custo_user_custo_user',
  'type' => 'link',
  'relationship' => 'custo_user_custo_user',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => 'custo_user',
  'vname' => 'LBL_CUSTO_USER_CUSTO_USER_FROM_CUSTO_USER_R_TITLE',
);
