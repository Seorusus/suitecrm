<?php
// created: 2020-10-15 00:18:13
$dictionary["ProspectList"]["fields"]["custo_user_prospectlists"] = array (
  'name' => 'custo_user_prospectlists',
  'type' => 'link',
  'relationship' => 'custo_user_prospectlists',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => 'custo_user',
  'vname' => 'LBL_CUSTO_USER_PROSPECTLISTS_FROM_CUSTO_USER_TITLE',
);
