<?php
// created: 2020-10-15 00:18:13
$dictionary["Email"]["fields"]["custo_user_emails"] = array (
  'name' => 'custo_user_emails',
  'type' => 'link',
  'relationship' => 'custo_user_emails',
  'source' => 'non-db',
  'module' => 'custo_user',
  'bean_name' => 'custo_user',
  'vname' => 'LBL_CUSTO_USER_EMAILS_FROM_CUSTO_USER_TITLE',
);
