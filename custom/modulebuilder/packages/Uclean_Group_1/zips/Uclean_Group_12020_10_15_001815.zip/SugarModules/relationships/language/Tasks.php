<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_CUSTO_CONTACT_TASKS_FROM_CUSTO_CONTACT_TITLE'] = 'Контакт Uclean_Group';
$mod_strings['LBL_CUSTO_USER_TASKS_FROM_CUSTO_USER_TITLE'] = 'Компания-партнер';
$mod_strings['LBL_CUSTO_USER_TASKS_1_FROM_CUSTO_USER_TITLE'] = 'Компания-партнер';
$mod_strings['LBL_CUSTO_COMPANY_TASKS_FROM_CUSTO_COMPANY_TITLE'] = 'Контрагент Uclean_Group';
