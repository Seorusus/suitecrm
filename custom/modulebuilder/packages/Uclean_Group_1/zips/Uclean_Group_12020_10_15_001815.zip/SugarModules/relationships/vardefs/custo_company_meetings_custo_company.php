<?php
// created: 2020-10-15 00:18:14
$dictionary["custo_company"]["fields"]["custo_company_meetings"] = array (
  'name' => 'custo_company_meetings',
  'type' => 'link',
  'relationship' => 'custo_company_meetings',
  'source' => 'non-db',
  'module' => 'Meetings',
  'bean_name' => 'Meeting',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_COMPANY_MEETINGS_FROM_MEETINGS_TITLE',
);
