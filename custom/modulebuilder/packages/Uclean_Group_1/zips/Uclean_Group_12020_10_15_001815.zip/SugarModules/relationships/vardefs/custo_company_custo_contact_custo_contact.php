<?php
// created: 2020-10-15 00:18:14
$dictionary["custo_contact"]["fields"]["custo_company_custo_contact"] = array (
  'name' => 'custo_company_custo_contact',
  'type' => 'link',
  'relationship' => 'custo_company_custo_contact',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => 'custo_company',
  'vname' => 'LBL_CUSTO_COMPANY_CUSTO_CONTACT_FROM_CUSTO_COMPANY_TITLE',
);
