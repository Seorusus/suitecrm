<?php
// created: 2020-10-15 00:18:14
$dictionary["custo_company"]["fields"]["custo_company_emails"] = array (
  'name' => 'custo_company_emails',
  'type' => 'link',
  'relationship' => 'custo_company_emails',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_COMPANY_EMAILS_FROM_EMAILS_TITLE',
);
