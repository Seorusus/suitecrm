<?php
// created: 2020-10-13 22:41:44
$dictionary["Call"]["fields"]["custo_contact_calls"] = array (
  'name' => 'custo_contact_calls',
  'type' => 'link',
  'relationship' => 'custo_contact_calls',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_CONTACT_CALLS_FROM_CUSTO_CONTACT_TITLE',
);
