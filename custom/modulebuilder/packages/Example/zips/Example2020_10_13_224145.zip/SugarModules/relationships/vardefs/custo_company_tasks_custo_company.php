<?php
// created: 2020-10-13 22:41:44
$dictionary["custo_company"]["fields"]["custo_company_tasks"] = array (
  'name' => 'custo_company_tasks',
  'type' => 'link',
  'relationship' => 'custo_company_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_COMPANY_TASKS_FROM_TASKS_TITLE',
);
