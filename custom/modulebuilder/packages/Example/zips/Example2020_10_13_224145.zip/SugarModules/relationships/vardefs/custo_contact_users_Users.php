<?php
// created: 2020-10-13 22:41:44
$dictionary["User"]["fields"]["custo_contact_users"] = array (
  'name' => 'custo_contact_users',
  'type' => 'link',
  'relationship' => 'custo_contact_users',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CUSTO_CONTACT_USERS_FROM_CUSTO_CONTACT_TITLE',
);
