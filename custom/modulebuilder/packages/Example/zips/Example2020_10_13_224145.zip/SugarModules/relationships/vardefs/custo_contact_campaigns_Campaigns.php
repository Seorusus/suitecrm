<?php
// created: 2020-10-13 22:41:44
$dictionary["Campaign"]["fields"]["custo_contact_campaigns"] = array (
  'name' => 'custo_contact_campaigns',
  'type' => 'link',
  'relationship' => 'custo_contact_campaigns',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CUSTO_CONTACT_CAMPAIGNS_FROM_CUSTO_CONTACT_TITLE',
);
