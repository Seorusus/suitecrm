<?php
// created: 2020-10-13 22:41:44
$dictionary["jjwg_Maps"]["fields"]["custo_contact_jjwg_maps"] = array (
  'name' => 'custo_contact_jjwg_maps',
  'type' => 'link',
  'relationship' => 'custo_contact_jjwg_maps',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CUSTO_CONTACT_JJWG_MAPS_FROM_CUSTO_CONTACT_TITLE',
);
