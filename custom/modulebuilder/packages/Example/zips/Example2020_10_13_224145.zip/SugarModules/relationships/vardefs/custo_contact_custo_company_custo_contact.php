<?php
// created: 2020-10-13 22:41:44
$dictionary["custo_contact"]["fields"]["custo_contact_custo_company"] = array (
  'name' => 'custo_contact_custo_company',
  'type' => 'link',
  'relationship' => 'custo_contact_custo_company',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_CONTACT_CUSTO_COMPANY_FROM_CUSTO_COMPANY_TITLE',
);
