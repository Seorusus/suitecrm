<?php
// created: 2020-10-13 22:41:44
$dictionary["custo_contact"]["fields"]["custo_contact_securitygroups"] = array (
  'name' => 'custo_contact_securitygroups',
  'type' => 'link',
  'relationship' => 'custo_contact_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_CUSTO_CONTACT_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
