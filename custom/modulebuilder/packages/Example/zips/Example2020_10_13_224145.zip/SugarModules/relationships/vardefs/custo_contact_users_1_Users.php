<?php
// created: 2020-10-13 22:41:44
$dictionary["User"]["fields"]["custo_contact_users_1"] = array (
  'name' => 'custo_contact_users_1',
  'type' => 'link',
  'relationship' => 'custo_contact_users_1',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_CONTACT_USERS_1_FROM_CUSTO_CONTACT_TITLE',
);
