<?php
// created: 2020-10-13 22:37:34
$dictionary["Email"]["fields"]["custo_contact_emails"] = array (
  'name' => 'custo_contact_emails',
  'type' => 'link',
  'relationship' => 'custo_contact_emails',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_CONTACT_EMAILS_FROM_CUSTO_CONTACT_TITLE',
);
