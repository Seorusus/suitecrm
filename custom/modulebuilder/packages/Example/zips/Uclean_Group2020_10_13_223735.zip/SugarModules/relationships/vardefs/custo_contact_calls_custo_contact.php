<?php
// created: 2020-10-13 22:37:34
$dictionary["custo_contact"]["fields"]["custo_contact_calls"] = array (
  'name' => 'custo_contact_calls',
  'type' => 'link',
  'relationship' => 'custo_contact_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_CUSTO_CONTACT_CALLS_FROM_CALLS_TITLE',
);
