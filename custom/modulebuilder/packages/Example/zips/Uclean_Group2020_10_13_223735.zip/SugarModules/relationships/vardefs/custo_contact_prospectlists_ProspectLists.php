<?php
// created: 2020-10-13 22:37:34
$dictionary["ProspectList"]["fields"]["custo_contact_prospectlists"] = array (
  'name' => 'custo_contact_prospectlists',
  'type' => 'link',
  'relationship' => 'custo_contact_prospectlists',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_CONTACT_PROSPECTLISTS_FROM_CUSTO_CONTACT_TITLE',
);
