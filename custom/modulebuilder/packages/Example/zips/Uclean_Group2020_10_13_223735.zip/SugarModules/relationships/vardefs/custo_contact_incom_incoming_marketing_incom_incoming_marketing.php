<?php
// created: 2020-10-13 22:37:34
$dictionary["incom_incoming_marketing"]["fields"]["custo_contact_incom_incoming_marketing"] = array (
  'name' => 'custo_contact_incom_incoming_marketing',
  'type' => 'link',
  'relationship' => 'custo_contact_incom_incoming_marketing',
  'source' => 'non-db',
  'module' => 'custo_contact',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_CUSTO_CONTACT_INCOM_INCOMING_MARKETING_FROM_CUSTO_CONTACT_TITLE',
);
