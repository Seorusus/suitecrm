<?php
// created: 2020-10-13 22:37:34
$dictionary["SecurityGroup"]["fields"]["custo_company_securitygroups"] = array (
  'name' => 'custo_company_securitygroups',
  'type' => 'link',
  'relationship' => 'custo_company_securitygroups',
  'source' => 'non-db',
  'module' => 'custo_company',
  'bean_name' => false,
  'vname' => 'LBL_CUSTO_COMPANY_SECURITYGROUPS_FROM_CUSTO_COMPANY_TITLE',
);
