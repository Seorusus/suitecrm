<?php
// created: 2020-10-13 22:37:34
$dictionary["custo_company"]["fields"]["custo_company_emails_1"] = array (
  'name' => 'custo_company_emails_1',
  'type' => 'link',
  'relationship' => 'custo_company_emails_1',
  'source' => 'non-db',
  'module' => 'Emails',
  'bean_name' => 'Email',
  'vname' => 'LBL_CUSTO_COMPANY_EMAILS_1_FROM_EMAILS_TITLE',
);
