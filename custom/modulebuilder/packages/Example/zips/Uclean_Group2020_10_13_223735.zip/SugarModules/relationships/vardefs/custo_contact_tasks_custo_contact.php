<?php
// created: 2020-10-13 22:37:34
$dictionary["custo_contact"]["fields"]["custo_contact_tasks"] = array (
  'name' => 'custo_contact_tasks',
  'type' => 'link',
  'relationship' => 'custo_contact_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'side' => 'right',
  'vname' => 'LBL_CUSTO_CONTACT_TASKS_FROM_TASKS_TITLE',
);
